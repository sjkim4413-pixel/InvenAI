import json


def validate_f03_data(data):
    if not isinstance(data, list):
        return False, "Data must be a list"

    locations = set()

    for index, row in enumerate(data, start=1):
        if not isinstance(row, dict):
            return False, f"Row {index}: Invalid object"

        required = [
            "location",
            "product_id",
            "confidence",
            "detection_state",
        ]

        for field in required:
            if field not in row:
                return False, f"Row {index}: Missing {field}"

        location = row["location"]

        if not isinstance(location, str) or not location.strip():
            return False, f"Row {index}: Invalid location"

        if location in locations:
            return False, f"Row {index}: Duplicate location"

        locations.add(location)

        state = row["detection_state"]

        if state not in {"detected", "empty", "unreadable"}:
            return False, f"Row {index}: Invalid detection_state"

        product_id = row["product_id"]
        confidence = row["confidence"]

        if product_id is not None and not isinstance(product_id, str):
            return False, f"Row {index}: Invalid product_id"

        if confidence is not None:
            if type(confidence) not in (int, float):
                return False, f"Row {index}: Invalid confidence"

            if not 0 <= confidence <= 1:
                return False, f"Row {index}: Confidence out of range"

        if state == "detected":
            if not product_id or confidence is None:
                return False, f"Row {index}: Incomplete detection"

    return True, "F-03 input validation passed"


if __name__ == "__main__":
    sample = [
        {
            "location": "A02",
            "product_id": "P011",
            "confidence": 0.95,
            "detection_state": "detected",
        },
        {
            "location": "A03",
            "product_id": None,
            "confidence": None,
            "detection_state": "empty",
        },
    ]

    valid, message = validate_f03_data(sample)

    print("VALID:", valid)
    print("MESSAGE:", message)
    