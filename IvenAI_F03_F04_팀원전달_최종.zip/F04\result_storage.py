import json
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent


def save_analysis_result(records):
    file_path = BASE_DIR / "latest_analysis.json"

    with open(file_path, "w", encoding="utf-8") as file:
        json.dump(
            records,
            file,
            ensure_ascii=False,
            indent=4
        )

    return file_path