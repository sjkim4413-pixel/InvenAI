import pandas as pd
# ===== InvenAI F-04 데이터 검증 모듈 =====

def validate_columns(expected, detected):

    expected_columns = ["location", "product_id"]

    detected_columns = [
        "location",
        "product_id",
        "confidence",
        "detection_state"
    ]

    missing_expected = [
        col for col in expected_columns
        if col not in expected.columns
    ]

    missing_detected = [
        col for col in detected_columns
        if col not in detected.columns
    ]

    if missing_expected or missing_detected:

        print("\n[오류] CSV 필수 항목이 누락되었습니다!")

        if missing_expected:
            print("전산 데이터 누락 항목:", missing_expected)

        if missing_detected:
            print("AI 판독 데이터 누락 항목:", missing_detected)

        raise SystemExit(
            "CSV 파일을 수정한 뒤 다시 실행하세요."
        )

    print("CSV 필수 항목 검사 통과! PASS")
    
def validate_duplicates(expected, detected):

    expected_duplicates = expected[
        expected.duplicated(subset=["location"], keep=False)
    ]

    detected_duplicates = detected[
        detected.duplicated(subset=["location"], keep=False)
    ]

    if not expected_duplicates.empty or not detected_duplicates.empty:
        print("\n[오류] 중복된 랙 위치가 발견되었습니다!")

        if not expected_duplicates.empty:
            print("\n[전산 데이터 중복 발견]")
            print(expected_duplicates.to_string(index=False))

        if not detected_duplicates.empty:
            print("\n[AI 판독 데이터 중복 발견]")
            print(detected_duplicates.to_string(index=False))

        raise SystemExit("중복 데이터를 수정한 뒤 다시 실행하세요.")

    print("중복 랙 위치 검사 통과! PASS")
    
def validate_confidence(detected):

    print("\n===== AI 신뢰도 검사 =====")

    confidence_values = pd.to_numeric(
        detected["confidence"],
        errors="coerce"
    )

    invalid_confidence = detected[
        confidence_values.isna()
        | (confidence_values < 0)
        | (confidence_values > 1)
    ]

    if not invalid_confidence.empty:
        print("[오류] 잘못된 AI 신뢰도가 발견되었습니다!")
        print(invalid_confidence.to_string(index=False))

        raise SystemExit(
            "confidence 값을 0~1 사이로 수정하세요."
        )

    detected["confidence"] = confidence_values

    print("AI 신뢰도 검사 통과! PASS")
    
def validate_detection_state(detected):

    print("\n===== AI 감지 상태 검사 =====")

    valid_states = ["detected", "empty", "unreadable"]

    invalid_states = detected[
        ~detected["detection_state"].isin(valid_states)
    ]

    if not invalid_states.empty:
        print("[오류] 잘못된 AI 감지 상태가 발견되었습니다!")
        print(invalid_states.to_string(index=False))

        raise SystemExit(
            "detection_state 값을 확인한 뒤 다시 실행하세요."
        )

    print("AI 감지 상태 검사 통과! PASS")
    
def validate_location_product(expected, detected):

    print("\n===== 랙 위치 및 제품 ID 검사 =====")

    invalid_expected = expected[
        expected["location"].isna()
        | expected["location"].astype("string").str.strip().eq("").fillna(False)
        | expected["product_id"].isna()
        | expected["product_id"].astype("string").str.strip().eq("").fillna(False)
    ]

    invalid_detected_location = detected[
        detected["location"].isna()
        | detected["location"].astype("string").str.strip().eq("").fillna(False)
    ]

    invalid_detected_id = detected[
        (detected["detection_state"] == "detected")
        & (
            detected["product_id"].isna()
            | detected["product_id"].astype("string").str.strip().eq("").fillna(False)
        )
    ]

    if (
        not invalid_expected.empty
        or not invalid_detected_location.empty
        or not invalid_detected_id.empty
    ):
        print("[오류] 필수 데이터가 비어 있습니다!")

        if not invalid_expected.empty:
            print("\n[전산 데이터 오류]")
            print(invalid_expected.to_string(index=False))

        if not invalid_detected_location.empty:
            print("\n[AI 판독 위치 오류]")
            print(invalid_detected_location.to_string(index=False))

        if not invalid_detected_id.empty:
            print("\n[AI 판독 제품 ID 오류]")
            print(invalid_detected_id.to_string(index=False))

        raise SystemExit(
            "CSV 데이터를 수정한 뒤 다시 실행하세요."
        )

    print("랙 위치 및 제품 ID 검사 통과! PASS")
    
def validate_ai_consistency(detected):

    print("\n===== AI 데이터 모순 검사 =====")

    has_product_id = (
        detected["product_id"].notna()
        & detected["product_id"].astype("string").str.strip().ne("").fillna(False)
    )

    invalid_empty = detected[
        (detected["detection_state"] == "empty")
        & has_product_id
    ]

    invalid_unreadable = detected[
        (detected["detection_state"] == "unreadable")
        & has_product_id
    ]

    if not invalid_empty.empty or not invalid_unreadable.empty:

        print("[오류] AI 감지 상태와 제품 ID가 서로 모순됩니다!")

        if not invalid_empty.empty:
            print("\n[빈 랙인데 제품 ID 존재]")
            print(invalid_empty.to_string(index=False))

        if not invalid_unreadable.empty:
            print("\n[판독 실패인데 제품 ID 존재]")
            print(invalid_unreadable.to_string(index=False))

        raise SystemExit(
            "AI 판독 데이터를 확인한 뒤 다시 실행하세요."
        )

    print("AI 데이터 모순 검사 통과! PASS")
def validate_ai_consistency(detected):
    print("\n===== AI 데이터 모순 검사 =====")

    has_product_id = (
        detected["product_id"].notna()
        & detected["product_id"].astype("string").str.strip().ne("").fillna(False)
    )

    invalid_empty = detected[
        (detected["detection_state"] == "empty")
        & has_product_id
    ]

    invalid_unreadable = detected[
        (detected["detection_state"] == "unreadable")
        & has_product_id
    ]

    if not invalid_empty.empty or not invalid_unreadable.empty:
        print("[오류] AI 감지 상태와 제품 ID가 서로 모순됩니다!")

        if not invalid_empty.empty:
            print("\n[빈 랙인데 제품 ID 존재]")
            print(invalid_empty.to_string(index=False))

        if not invalid_unreadable.empty:
            print("\n[판독 실패인데 제품 ID 존재]")
            print(invalid_unreadable.to_string(index=False))

        raise SystemExit("AI 판독 데이터를 확인한 뒤 다시 실행하세요.")

    print("AI 데이터 모순 검사 통과! PASS")
    
def check_result_files(required_files):
    import os
    import json

    file_check_results = []

    for filename in required_files:

        # 파일 존재 여부 확인
        exists = os.path.isfile(filename)

        # 파일 크기 확인
        file_size = (
            os.path.getsize(filename)
            if exists else 0
        )

        # 파일 내용 검사
        readable = False
        error_message = ""

        if exists and file_size > 0:

            try:
                if filename.endswith(".json"):

                    with open(
                        filename,
                        "r",
                        encoding="utf-8"
                    ) as file:
                        json.load(file)

                elif filename.endswith(".csv"):

                    with open(
                        filename,
                        "r",
                        encoding="utf-8-sig"
                    ) as file:
                        header = file.readline()

                        if not header.strip():
                            raise ValueError(
                                "CSV 헤더가 비어 있습니다."
                            )

                readable = True

            except Exception as error:
                error_message = str(error)

        # 최종 파일 상태
        file_passed = (
            exists
            and file_size > 0
            and readable
        )

        status = "PASS" if file_passed else "FAIL"

        # 검사 결과 저장
        file_check_results.append({
            "filename": filename,
            "exists": exists,
            "file_size": file_size,
            "readable": readable,
            "status": status,
            "error": error_message
        })

    return file_check_results

def get_required_files():
    return [
        "final_inventory_report.csv",
        "final_anomalies_report.csv",
        "final_action_report.csv",
        "final_priority_report.csv",
        "worker_completed.csv",
        "worker_pending.csv",
        "work_order.csv",
        "work_order_summary.json",
        "dashboard.json",
        "validation_report.json",
        "validation_error_report.json"
    ]