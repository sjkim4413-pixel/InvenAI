﻿
package com.example.myapp

import retrofit2.Retrofit
import retrofit2.converter.gson.GsonConverterFactory

object F03RetrofitClient {

    // Android ?먮??덉씠?곗뿉??PC??F-03 ?쒕쾭 ?묒냽
    private const val BASE_URL = "http://10.0.2.2:8082/"

    val retrofit: Retrofit by lazy {
        Retrofit.Builder()
            .baseUrl(BASE_URL)
            .addConverterFactory(GsonConverterFactory.create())
            .build()
    }
}

