import csv
from pathlib import Path

BASE_DIR = Path(__file__).resolve().parent
ERP_FILE = BASE_DIR / "IvenAI_ERP_25_positions.csv"


def _normalize_product_id(value):
    """ERP 빈칸/엑셀 숫자 0 등을 실제 제품 ID로 오인하지 않도록 정리."""
    product = str(value or "").strip()
    if product.lower() in {"", "0", "0.0", "nan", "none", "null"}:
        return ""
    return product


def _explicitly_verified(item):
    """검증 단계가 명시적으로 통과했다고 전달된 경우만 인정한다."""
    return item.get("verification_passed") is True


def compare_with_erp(ai_result):
    with ERP_FILE.open("r", encoding="utf-8-sig", newline="") as f:
        erp_rows = list(csv.DictReader(f))

    erp_map = {
        (row["랙번호"].strip(), int(row["단수"])): row
        for row in erp_rows
    }

    comparison = []
    for item in ai_result["results"]:
        rack = str(item["랙번호"]).strip()
        floor = int(item["단수"])
        detected = _normalize_product_id(item.get("인식제품ID"))
        candidates = int(item.get("YOLO탐지후보수") or 0)
        erp = erp_map.get((rack, floor))

        if erp is None:
            expected = []
            status = "ERP위치없음_확인필요"
        else:
            expected = [
                _normalize_product_id(erp.get("ERP_왼쪽제품")),
                _normalize_product_id(erp.get("ERP_오른쪽제품")),
            ]
            expected = [product for product in expected if product]

            if detected and detected not in expected:
                status = "미등록_또는_오적재의심"
            elif detected and detected in expected:
                # 하나의 OCR ID만 일치했다고 다수 파렛트의 재고가 검증된 것은 아님.
                # 현재 파이프라인에는 verification_passed가 없어 기존처럼 재확인으로 남음.
                if (
                    _explicitly_verified(item)
                    and len(expected) == 1
                    and expected[0] == detected
                ):
                    status = "PASS"
                else:
                    status = "제품ID일치_추가검증필요"
            elif candidates > 0:
                status = "YOLO탐지_OCR미인식_재확인"
            elif expected:
                status = "전산재고_미탐지_재확인"
            else:
                status = "빈위치_재확인필요"

        comparison.append({
            "rack": rack,
            "floor": floor,
            "erp_product_ids": expected,
            "ai_product_id": detected,
            "yolo_candidates": candidates,
            "review_status": status,
        })

    return {
        "status": "compared",
        "total_positions": len(comparison),
        "results": comparison,
    }
