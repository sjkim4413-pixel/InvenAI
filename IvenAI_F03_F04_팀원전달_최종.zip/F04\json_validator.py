import json
from pathlib import Path


def load_json_safely(file_path, default=None):
    path = Path(file_path)

    # 파일이 없을 때만 기본값 반환
    if not path.exists():
        return [] if default is None else default

    # 파일이 아닌 경로 방지
    if not path.is_file():
        raise ValueError(f"파일이 아닌 경로입니다: {path}")

    try:
        with open(path, "r", encoding="utf-8") as file:
            data = json.load(file)

    except (json.JSONDecodeError, UnicodeDecodeError) as error:
        raise ValueError(
            f"JSON 파일이 손상되었거나 인코딩이 올바르지 않습니다: {path}"
        ) from error

    # 재확인 기록은 JSON 배열 형태여야 함
    if not isinstance(data, list):
        raise ValueError(
            f"JSON 데이터가 목록 형태가 아닙니다: {path}"
        )

    return data