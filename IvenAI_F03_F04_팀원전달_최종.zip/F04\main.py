from reporter import (
    save_inventory_result,
    save_anomalies_result,
    count_inventory_status,
    count_anomalies,
    save_summary,
    create_final_zip,
    copy_final_files,
    get_final_files
)
from merger import merge_inventory
import pandas as pd
import json
import shutil
from pathlib import Path
import zipfile
from classifier import check_status
from validator import (
    validate_columns,
    validate_duplicates,
    validate_confidence,
    validate_detection_state,
    validate_location_product,
    validate_ai_consistency,
    check_result_files
)
from validator import get_required_files
# ===== STEP 1: CSV 파일 불러오기 =====
expected = pd.read_csv("expected.csv")
detected = pd.read_csv("detected.csv")


# ===== STEP 2: CSV 필수 항목 검사 =====
validate_columns(expected, detected)

# ===== STEP 3: 중복 랙 위치 검사 =====
validate_duplicates(expected, detected)


# ===== STEP 26: AI 신뢰도 검사 =====
validate_confidence(detected)


# ===== STEP 27: AI 감지 상태 검사 =====
validate_detection_state(detected)

# ===== STEP 28: 랙 위치 및 제품 ID 검사 =====
validate_location_product(expected, detected)

# ===== STEP 29: AI 데이터 모순 검사 =====
print("\n===== AI 데이터 모순 검사 =====")

has_product_id = (
    detected["product_id"].notna()
    & detected["product_id"].astype("string").str.strip().ne("").fillna(False)
)

invalid_empty = detected[
    (detected["detection_state"] == "empty")
    & has_product_id
]

invalid_unreadable = detected[
    (detected["detection_state"] == "unreadable")
    & has_product_id
]

if not invalid_empty.empty or not invalid_unreadable.empty:
    print("[오류] AI 감지 상태와 제품 ID가 서로 모순됩니다!")

    if not invalid_empty.empty:
        print("\n[빈 랙인데 제품 ID 존재]")
        print(invalid_empty.to_string(index=False))

    if not invalid_unreadable.empty:
        print("\n[판독 실패인데 제품 ID 존재]")
        print(invalid_unreadable.to_string(index=False))

    raise SystemExit(
        "AI 판독 데이터를 확인한 뒤 다시 실행하세요."
    )

print("AI 데이터 모순 검사 통과! PASS")


# ===== STEP 4: 데이터 병합 =====
merged = merge_inventory(expected, detected)


# ===== STEP 5 + STEP 30: 재고 상태 자동 판정 =====


merged[["status_code", "status"]] = merged.apply(
    check_status,
    axis=1,
    result_type="expand"
)

print("\n===== 최종 재고 판정 결과 =====")
print(
    merged[
        [
            "location",
            "product_id_expected",
            "product_id_detected",
            "status_code",
            "status"
        ]
    ].to_string(index=False)
)


# ===== STEP 6: 전체 결과 JSON 저장 =====
save_inventory_result(merged)

# ===== STEP 7: 이상 위치 추출 =====
anomalies = merged[merged["status_code"] != 1]

print("\n===== 이상 위치 목록 =====")

if anomalies.empty:
    print("ALL PASS - 이상 위치가 없습니다.")

else:
    for _, row in anomalies.iterrows():
        print(f'{row["location"]} → {row["status"]}')


# ===== STEP 8: 이상 위치 JSON 저장 =====
save_anomalies_result(anomalies)
# ===== 모듈화 STEP 14: 이상 위치 집계 =====
anomaly_total, anomaly_counts = count_anomalies(anomalies)

# ===== STEP 9: 재고 상태별 개수 집계 =====
total_count, status_counts = count_inventory_status(merged)
normal_count = status_counts.get("정상", 0)
wrong_count = status_counts.get("오적재", 0)
missing_count = status_counts.get("누락", 0)
unregistered_count = status_counts.get("미등록", 0)
manual_count = status_counts.get("수동확인", 0)
uncaptured_count = status_counts.get("미촬영", 0)

# ===== STEP 10: 요약 JSON 저장 =====
summary = {
    "total": total_count,
    "normal": normal_count,
    "wrong": wrong_count,
    "missing": missing_count,
    "unregistered": unregistered_count,
    "manual_check": manual_count
}
save_summary(summary)

print("\n재고 실사 요약 JSON 저장 완료!")
# ===== STEP 31: 미촬영 랙 자동 추출 =====

print("\n===== 미촬영 랙 목록 =====")

# 미촬영 상태인 랙만 선택
uncaptured = merged[merged["status"] == "미촬영"]

# 저장할 데이터 선택
uncaptured_result = uncaptured[
    ["location", "product_id_expected", "status_code", "status"]
].copy()

# 빈 값을 JSON에 맞게 변환
uncaptured_result = uncaptured_result.astype(object).where(
    pd.notna(uncaptured_result), None
)

# JSON 형태로 변환
uncaptured_data = uncaptured_result.to_dict(orient="records")

# 미촬영 랙 출력
if uncaptured.empty:
    print("미촬영 랙이 없습니다.")
else:
    for _, row in uncaptured.iterrows():
        print(
            f'{row["location"]} → 미촬영 | '
            f'전산 제품: {row["product_id_expected"]}'
        )

# 파일 저장
with open("uncaptured.json", "w", encoding="utf-8") as file:
    json.dump(uncaptured_data, file, ensure_ascii=False, indent=4)

print(f"미촬영 랙 총 {len(uncaptured_data)}개")
print("미촬영 랙 JSON 저장 완료!")
# ===== STEP 32: AI 판독 실패 랙 추출 =====

print("\n===== AI 판독 실패 랙 목록 =====")

# AI가 판독에 실패한 랙만 선택
unreadable = merged[
    merged["detection_state"] == "unreadable"
]

# 저장할 항목 선택
unreadable_result = unreadable[
    ["location", "product_id_expected", "status_code", "status"]
].copy()

# 빈 값을 JSON 형식에 맞게 변환
unreadable_result = unreadable_result.astype(object).where(
    pd.notna(unreadable_result), None
)

# JSON 데이터 만들기
unreadable_data = unreadable_result.to_dict(orient="records")

# 판독 실패 랙 출력
if unreadable.empty:
    print("AI 판독 실패 랙이 없습니다.")
else:
    for _, row in unreadable.iterrows():
        print(f'{row["location"]} → AI 판독 실패 | 재촬영 필요')

# JSON 파일 저장
with open("unreadable.json", "w", encoding="utf-8") as file:
    json.dump(unreadable_data, file, ensure_ascii=False, indent=4)

print(f"AI 판독 실패 랙 총 {len(unreadable_data)}개")
print("AI 판독 실패 JSON 저장 완료!")
# ===== STEP 33: AI 신뢰도 부족 랙 추출 =====

print("\n===== AI 신뢰도 부족 랙 목록 =====")

# 제품은 감지했지만 신뢰도가 0.7 미만인 랙 선택
low_confidence = merged[
    (merged["detection_state"] == "detected")
    & (merged["confidence"] < 0.7)
].copy()

# 저장할 항목 선택
low_confidence_result = low_confidence[
    [
        "location",
        "product_id_expected",
        "product_id_detected",
        "confidence",
        "status_code",
        "status"
    ]
].copy()

# 빈 값을 JSON에 맞게 변환
low_confidence_result = low_confidence_result.astype(object).where(
    pd.notna(low_confidence_result), None
)

# JSON 데이터로 변환
low_confidence_data = low_confidence_result.to_dict(orient="records")

# 신뢰도 부족 랙 출력
if low_confidence.empty:
    print("AI 신뢰도 부족 랙이 없습니다.")
else:
    for _, row in low_confidence.iterrows():
        print(
            f'{row["location"]} → 신뢰도 부족 '
            f'({row["confidence"]:.2f}) | 재확인 필요'
        )

# JSON 파일 저장
with open("low_confidence.json", "w", encoding="utf-8") as file:
    json.dump(
        low_confidence_data,
        file,
        ensure_ascii=False,
        indent=4
    )

print(f"AI 신뢰도 부족 랙 총 {len(low_confidence_data)}개")
print("AI 신뢰도 부족 JSON 저장 완료!")
# ===== STEP 34: 현장 재확인 대상 통합 =====

print("\n===== 현장 재확인 대상 목록 =====")

# 재확인 대상 랙만 선택
recheck = merged[
    (merged["status"] == "미촬영")
    | (merged["detection_state"] == "unreadable")
    | (
        (merged["detection_state"] == "detected")
        & (merged["confidence"] < 0.7)
    )
].copy()


# 재확인 사유 구분
def get_recheck_reason(row):

    if row["status"] == "미촬영":
        return "미촬영"

    if row["detection_state"] == "unreadable":
        return "AI 판독 실패"

    if (
        row["detection_state"] == "detected"
        and row["confidence"] < 0.7
    ):
        return "AI 신뢰도 부족"

    return "기타"


# 재확인 사유 추가
recheck["reason"] = recheck.apply(
    get_recheck_reason,
    axis=1
)


# 저장할 데이터 선택
recheck_result = recheck[
    [
        "location",
        "product_id_expected",
        "product_id_detected",
        "status_code",
        "status",
        "reason"
    ]
].copy()


# 빈 값을 JSON에 맞게 변환
recheck_result = recheck_result.astype(object).where(
    pd.notna(recheck_result),
    None
)


# JSON 데이터로 변환
recheck_data = recheck_result.to_dict(orient="records")


# 재확인 대상 출력
if recheck.empty:
    print("재확인 대상이 없습니다.")

else:
    for _, row in recheck.iterrows():
        print(
            f'{row["location"]} → {row["reason"]}'
        )


# JSON 파일 저장
with open("recheck.json", "w", encoding="utf-8") as file:
    json.dump(
        recheck_data,
        file,
        ensure_ascii=False,
        indent=4
    )


print(f"현장 재확인 대상 총 {len(recheck_data)}개")
print("현장 재확인 대상 JSON 저장 완료!")
# ===== STEP 35: 재확인 우선순위 자동 지정 =====

print("\n===== 재확인 우선순위 =====")

# 재확인 사유별 우선순위 설정
priority_rules = {
    "미촬영": 1,
    "AI 판독 실패": 2,
    "AI 신뢰도 부족": 3
}

# STEP 34에서 만든 재확인 목록에 우선순위 추가
recheck["priority"] = recheck["reason"].map(priority_rules)

# 우선순위가 높은 순서대로 정렬
recheck = recheck.sort_values(
    by=["priority", "location"]
)

# 현장 작업 순서 출력
for _, row in recheck.iterrows():
    print(
        f'{int(row["priority"])}순위 | '
        f'{row["location"]} → {row["reason"]}'
    )

# 저장할 데이터 선택
priority_result = recheck[
    [
        "location",
        "product_id_expected",
        "product_id_detected",
        "status_code",
        "status",
        "reason",
        "priority"
    ]
].copy()

# 빈 값을 JSON 형식에 맞게 변환
priority_result = priority_result.astype(object).where(
    pd.notna(priority_result), None
)

# JSON 파일 저장
priority_data = priority_result.to_dict(orient="records")

with open("recheck_priority.json", "w", encoding="utf-8") as file:
    json.dump(
        priority_data,
        file,
        ensure_ascii=False,
        indent=4
    )

print(f"우선순위 지정 완료! 총 {len(priority_data)}개")
print("재확인 우선순위 JSON 저장 완료!")
# ===== STEP 36: 현장 재확인 작업 상태 관리 =====

# ===== STEP 37: 작업 상태 유지 기능 =====

import os

print("\n===== 현장 재확인 작업 관리 =====")

# STEP 35에서 정렬한 재확인 목록 복사
work_list = recheck.copy()

# 작업 상태별 코드
work_status_codes = {
    "확인 대기": 0,
    "확인 중": 1,
    "확인 완료": 2
}

# 기본값은 확인 대기
work_list["work_status"] = "확인 대기"

# 이전 작업 상태 파일이 있는지 확인
if os.path.exists("work_status.json"):

    print("기존 작업 상태 파일 발견!")

    with open("work_status.json", "r", encoding="utf-8") as file:
        previous_work = json.load(file)

    # 이전 작업 상태를 위치별로 정리
    previous_status = {}

    for item in previous_work:
        location = item["location"]
        status = item["work_status"]

        if status in work_status_codes:
            previous_status[location] = status

    # 기존 상태 복원
    for index, row in work_list.iterrows():
        location = row["location"]

        if location in previous_status:
            work_list.at[index, "work_status"] = previous_status[location]

else:
    print("기존 작업 상태 없음! 새 작업 목록 생성")

# 작업 상태 코드 추가
work_list["work_status_code"] = work_list["work_status"].map(
    work_status_codes
)

# 저장할 항목 선택
work_result = work_list[
    [
        "location",
        "reason",
        "priority",
        "work_status",
        "work_status_code"
    ]
].copy()

# JSON 데이터 만들기
work_data = work_result.to_dict(orient="records")

# 작업 목록 출력
for _, row in work_list.iterrows():
    print(
        f'{row["location"]} → '
        f'{row["reason"]} | '
        f'작업 상태: {row["work_status"]}'
    )

# JSON 파일 저장
with open("work_status.json", "w", encoding="utf-8") as file:
    json.dump(
        work_data,
        file,
        ensure_ascii=False,
        indent=4
    )

print(f"현장 재확인 작업 총 {len(work_data)}개")
print("작업 상태 저장 완료!")

print(f"현장 재확인 작업 총 {len(work_data)}개")
print("작업 상태 JSON 저장 완료!")
# ===== STEP 38: 터미널에서 작업 상태 변경 =====

print("\n===== 작업 상태 변경 =====")

# 작업할 랙 위치 입력
target_location = input(
    "상태를 변경할 랙 번호 입력 (건너뛰기: Enter): "
).strip().upper()

# 아무것도 입력하지 않으면 변경하지 않음
if target_location == "":
    print("작업 상태 변경을 건너뜁니다.")

elif target_location not in work_list["location"].values:
    print("[오류] 재확인 대상에 없는 랙입니다.")

else:
    print("\n변경할 작업 상태를 선택하세요.")
    print("0 → 확인 대기")
    print("1 → 확인 중")
    print("2 → 확인 완료")

    choice = input("번호 입력: ").strip()

    status_options = {
        "0": "확인 대기",
        "1": "확인 중",
        "2": "확인 완료"
    }

    if choice not in status_options:
        print("[오류] 0, 1, 2 중에서 선택하세요.")

    else:
        new_status = status_options[choice]

        # 선택한 랙의 작업 상태 변경
        work_list.loc[
            work_list["location"] == target_location,
            "work_status"
        ] = new_status

        # 작업 상태 코드 변경
        work_list["work_status_code"] = work_list[
            "work_status"
        ].map(work_status_codes)

        # 변경한 결과 저장
        updated_work = work_list[
            [
                "location",
                "reason",
                "priority",
                "work_status",
                "work_status_code"
            ]
        ].to_dict(orient="records")

        with open(
            "work_status.json",
            "w",
            encoding="utf-8"
        ) as file:
            json.dump(
                updated_work,
                file,
                ensure_ascii=False,
                indent=4
            )

        print(
            f"\n변경 완료! {target_location} → {new_status}"
        )
        print("work_status.json 저장 완료!")
# ===== STEP 39: 현장 재확인 작업 완료율 계산 =====

print("\n===== 현장 재확인 작업 진행률 =====")

# 전체 작업 개수
total_work = len(work_list)

# 확인 완료된 작업 개수
completed_work = int(
    (work_list["work_status"] == "확인 완료").sum()
)

# 확인 중인 작업 개수
progress_work = int(
    (work_list["work_status"] == "확인 중").sum()
)

# 확인 대기 중인 작업 개수
waiting_work = int(
    (work_list["work_status"] == "확인 대기").sum()
)

# 작업 완료율 계산
if total_work == 0:
    completion_rate = 100.0
else:
    completion_rate = (completed_work / total_work) * 100

# 결과 출력
print(f"전체 작업: {total_work}개")
print(f"확인 완료: {completed_work}개")
print(f"확인 중: {progress_work}개")
print(f"확인 대기: {waiting_work}개")
print(f"작업 완료율: {completion_rate:.1f}%")

# JSON 저장
progress_summary = {
    "total": total_work,
    "completed": completed_work,
    "in_progress": progress_work,
    "waiting": waiting_work,
    "completion_rate": round(completion_rate, 1)
}

with open("work_progress.json", "w", encoding="utf-8") as file:
    json.dump(
        progress_summary,
        file,
        ensure_ascii=False,
        indent=4
    )

print("작업 진행률 JSON 저장 완료!")
# ===== STEP 40: 작업 진행률 막대 표시 =====

print("\n===== 현장 작업 진행률 =====")

# 진행률 막대의 전체 길이
bar_length = 30

# 완료율에 따라 채워질 칸 수 계산
filled_length = round(
    bar_length * completion_rate / 100
)

# 진행률 막대 생성
progress_bar = (
    "█" * filled_length
    + "░" * (bar_length - filled_length)
)

# 진행률 출력
print(f"[{progress_bar}] {completion_rate:.1f}%")

# 완료 상태 안내
if total_work == 0:
    print("재확인 대상이 없습니다.")

elif completed_work == total_work:
    print("모든 재확인 작업이 완료되었습니다!")

else:
    remaining_work = total_work - completed_work
    print(f"남은 작업: {remaining_work}개")
# ===== STEP 41: 최종 작업 완료 보고서 =====

print("\n===== 최종 작업 완료 보고서 =====")

# 전체 재확인 작업 상태 판단
if total_work == 0:
    final_status = "재확인 대상 없음"

elif completed_work == total_work:
    final_status = "작업 완료"

else:
    final_status = "진행 중"


# 최종 보고서 생성
final_report = {
    "project": "InvenAI",
    "module": "F-04",
    "total_inventory": total_count,
    "normal": normal_count,
    "wrong": wrong_count,
    "missing": missing_count,
    "unregistered": unregistered_count,
    "manual_check": manual_count,
    "total_recheck": total_work,
    "completed_recheck": completed_work,
    "in_progress_recheck": progress_work,
    "waiting_recheck": waiting_work,
    "completion_rate": round(completion_rate, 1),
    "final_status": final_status
}

# ===== STEP 42: 랙별 작업 상세 목록 =====

print("\n===== 랙별 재확인 작업 상세 =====")

# 확인 완료한 랙
completed_list = work_list[
    work_list["work_status"] == "확인 완료"
]

# 아직 확인 완료하지 않은 랙
remaining_list = work_list[
    work_list["work_status"] != "확인 완료"
]

# JSON에 저장할 상세 데이터
final_report["completed_locations"] = completed_list[
    ["location", "reason", "work_status"]
].to_dict(orient="records")

final_report["remaining_locations"] = remaining_list[
    ["location", "reason", "work_status"]
].to_dict(orient="records")

# 확인 완료 랙 출력
print("\n[확인 완료 랙]")

if completed_list.empty:
    print("없음")
else:
    for _, row in completed_list.iterrows():
        print(f'{row["location"]} → {row["reason"]} | 확인 완료')

# 미완료 랙 출력
print("\n[아직 남은 랙]")

if remaining_list.empty:
    print("없음")
else:
    for _, row in remaining_list.iterrows():
        print(
            f'{row["location"]} → '
            f'{row["reason"]} | {row["work_status"]}'
        )

# ===== STEP 43: 최종 재고 이상 여부 판정 =====

print("\n===== 최종 재고 이상 여부 =====")

# 전체 재고 중 정상(코드 1)이 아닌 랙 선택
remaining_anomalies = merged[
    merged["status_code"] != 1
].copy()

# 남아 있는 재고 이상 개수
remaining_anomaly_count = len(remaining_anomalies)

# 재확인 작업 완료 여부와 재고 판정 결과를 구분
if total_work > 0 and completed_work < total_work:
    inventory_status = "재확인 작업 진행 중"

elif remaining_anomaly_count == 0:
    inventory_status = "ALL PASS"

else:
    inventory_status = "재고 이상 또는 미해결 항목 존재"

# 최종 보고서에 추가
final_report["remaining_anomaly_count"] = remaining_anomaly_count
final_report["inventory_status"] = inventory_status

# 재고 이상 상세 목록 추가
anomaly_detail = remaining_anomalies[
    [
        "location",
        "product_id_expected",
        "product_id_detected",
        "status_code",
        "status"
    ]
].copy()

anomaly_detail = anomaly_detail.astype(object).where(
    pd.notna(anomaly_detail), None
)

final_report["remaining_anomalies"] = anomaly_detail.to_dict(
    orient="records"
)

# 결과 출력
print(f"재고 이상 및 미해결 항목: {remaining_anomaly_count}개")
print(f"최종 재고 상태: {inventory_status}")

if remaining_anomalies.empty:
    print("ALL PASS - 모든 재고 위치 정상")
else:
    for _, row in remaining_anomalies.iterrows():
        print(f'{row["location"]} → {row["status"]}')
# 최종 보고서 출력
print(f"전체 재고 검사: {total_count}개")
print(f"재확인 대상: {total_work}개")
print(f"확인 완료: {completed_work}개")
print(f"확인 중: {progress_work}개")
print(f"확인 대기: {waiting_work}개")
print(f"작업 완료율: {completion_rate:.1f}%")
print(f"최종 작업 상태: {final_status}")


# JSON 파일 저장
with open("final_report.json", "w", encoding="utf-8") as file:
    json.dump(
        final_report,
        file,
        ensure_ascii=False,
        indent=4
    )

print("최종 작업 보고서 JSON 저장 완료!")
# ===== STEP 44: 현장 확인 결과 입력 및 재판정 =====

print("\n===== 현장 확인 결과 입력 =====")

# 기존 현장 확인 결과 불러오기
try:
    with open("verified_inventory.json", "r", encoding="utf-8") as file:
        verified_data = json.load(file)

except FileNotFoundError:
    verified_data = []

# 기존 확인 결과를 랙 위치별로 정리
verified_map = {
    item["location"]: item
    for item in verified_data
}

# 확인할 랙 번호 입력
target_location = input(
    "실제 재고를 확인할 랙 번호 (건너뛰기: Enter): "
).strip().upper()

if target_location == "":
    print("현장 재고 확인을 건너뜁니다.")

elif target_location not in merged["location"].values:
    print("[오류] 존재하지 않는 랙 위치입니다.")

else:
    target_row = merged[
        merged["location"] == target_location
    ].iloc[0]

    expected_id = target_row["product_id_expected"]

    print(f"\n선택한 랙: {target_location}")
    print(f"전산 제품: {expected_id}")

    print("\n현장에서 확인한 결과를 입력하세요.")
    print("제품이 있으면 제품 ID 입력 (예: P006)")
    print("실제로 비어 있으면 EMPTY 입력")

    actual_input = input("실제 확인 결과: ").strip().upper()

    if actual_input == "":
        print("[오류] 확인 결과가 입력되지 않았습니다.")

    else:
        # 빈 랙과 실제 제품을 구분
        actual_id = None if actual_input == "EMPTY" else actual_input

        # 현장 확인 결과로 재판정
        if pd.isna(expected_id):
            if actual_id is None:
                new_code = 1
                new_status = "정상"
            else:
                new_code = 4
                new_status = "미등록"

        elif actual_id is None:
            new_code = 3
            new_status = "누락"

        elif expected_id == actual_id:
            new_code = 1
            new_status = "정상"

        else:
            new_code = 2
            new_status = "오적재"

        # 기존 확인 결과가 있으면 갱신
        verified_map[target_location] = {
            "location": target_location,
            "product_id_expected": (
                None if pd.isna(expected_id) else expected_id
            ),
            "product_id_verified": actual_id,
            "status_code": new_code,
            "status": new_status,
            "verification_state": "현장 확인 완료"
        }

        # 현장 확인 결과 저장
        with open(
            "verified_inventory.json",
            "w",
            encoding="utf-8"
        ) as file:
            json.dump(
                list(verified_map.values()),
                file,
                ensure_ascii=False,
                indent=4
            )

        print("\n===== 현장 확인 재판정 결과 =====")
        print(f"랙 위치: {target_location}")
        print(f"실제 제품: {actual_id}")
        print(f"판정 결과: {new_status}")
        print("verified_inventory.json 저장 완료!")

# ===== STEP 45: AI 판정과 현장 확인 결과 통합 =====

print("\n===== 최종 재고 판정 통합 =====")

# AI 최초 판정 결과 복사
final_inventory = merged.copy()

# 현장 확인 결과를 랙 위치별로 정리
verified_lookup = {
    item["location"]: item
    for item in verified_map.values()
}

# 최종 판정 출처 표시
final_inventory["verification_source"] = "AI 판정"

# 현장 확인 결과가 있는 랙만 갱신
for index, row in final_inventory.iterrows():

    location = row["location"]

    if location in verified_lookup:

        verified_item = verified_lookup[location]

        final_inventory.at[
            index, "product_id_detected"
        ] = verified_item["product_id_verified"]

        final_inventory.at[
            index, "status_code"
        ] = verified_item["status_code"]

        final_inventory.at[
            index, "status"
        ] = verified_item["status"]

        final_inventory.at[
            index, "verification_source"
        ] = "현장 확인"


# 최종 판정 결과 출력
print("\n[최종 재고 판정 목록]")

for _, row in final_inventory.iterrows():

    print(
        f'{row["location"]} → '
        f'{row["status"]} | '
        f'{row["verification_source"]}'
    )


# JSON 저장을 위한 데이터 정리
final_inventory_data = final_inventory[
    [
        "location",
        "product_id_expected",
        "product_id_detected",
        "status_code",
        "status",
        "verification_source"
    ]
].copy()

final_inventory_data = final_inventory_data.astype(object).where(
    pd.notna(final_inventory_data),
    None
)

# 최종 통합 결과 JSON 저장
with open(
    "final_inventory.json",
    "w",
    encoding="utf-8"
) as file:

    json.dump(
        final_inventory_data.to_dict(orient="records"),
        file,
        ensure_ascii=False,
        indent=4
    )

print("\nfinal_inventory.json 저장 완료!")
# ===== STEP 46: 현장 확인 반영 최종 보고서 갱신 =====

print("\n===== 현장 확인 반영 최종 보고서 =====")

# 최종 통합 데이터에서 정상 외 항목 추출
final_anomalies = final_inventory[
    final_inventory["status_code"] != 1
].copy()

# 최종 정상 및 이상 개수 계산
final_normal_count = int(
    (final_inventory["status_code"] == 1).sum()
)

final_anomaly_count = len(final_anomalies)

# 현장 확인이 반영된 랙 개수
verified_count = int(
    (final_inventory["verification_source"] == "현장 확인").sum()
)

# 작업 완료 여부와 재고 이상 여부 구분
if total_work > 0 and completed_work < total_work:
    updated_inventory_status = "재확인 작업 진행 중"

elif final_anomaly_count == 0:
    updated_inventory_status = "ALL PASS"

else:
    updated_inventory_status = "재고 이상 또는 미해결 항목 존재"


# 최종 이상 목록 JSON 변환
final_anomaly_data = final_anomalies[
    [
        "location",
        "product_id_expected",
        "product_id_detected",
        "status_code",
        "status",
        "verification_source"
    ]
].copy()

final_anomaly_data = final_anomaly_data.astype(object).where(
    pd.notna(final_anomaly_data),
    None
)

# STEP 41~43 보고서 내용 갱신
final_report["normal"] = final_normal_count
final_report["remaining_anomaly_count"] = final_anomaly_count
final_report["remaining_anomalies"] = final_anomaly_data.to_dict(
    orient="records"
)

final_report["inventory_status"] = updated_inventory_status
final_report["verified_location_count"] = verified_count

# 최종 상태별 개수도 갱신
final_report["wrong"] = int(
    (final_inventory["status_code"] == 2).sum()
)

final_report["missing"] = int(
    (final_inventory["status_code"] == 3).sum()
)

final_report["unregistered"] = int(
    (final_inventory["status_code"] == 4).sum()
)

final_report["manual_check"] = int(
    (final_inventory["status_code"] == 5).sum()
)

# 최종 보고서 다시 저장
with open("final_report.json", "w", encoding="utf-8") as file:
    json.dump(
        final_report,
        file,
        ensure_ascii=False,
        indent=4
    )

# 결과 출력
print(f"전체 검사 위치: {len(final_inventory)}개")
print(f"정상 위치: {final_normal_count}개")
print(f"이상 및 미해결 위치: {final_anomaly_count}개")
print(f"현장 확인 반영 위치: {verified_count}개")
print(f"최종 재고 상태: {updated_inventory_status}")

print("\n[최종 이상 및 미해결 위치]")

if final_anomalies.empty:
    print("ALL PASS")
else:
    for _, row in final_anomalies.iterrows():
        print(f'{row["location"]} → {row["status"]}')

print("\nfinal_report.json 갱신 완료!")
# ===== STEP 47: 현장 확인 작업 상태 자동 완료 =====

print("\n===== 현장 확인 작업 상태 자동 갱신 =====")

# 현장 확인 기록이 있는 랙 위치
verified_locations = set(verified_map.keys())

# 현장 확인이 완료된 재확인 대상 랙 찾기
auto_completed_locations = []

for index, row in work_list.iterrows():

    location = row["location"]

    if location in verified_locations:

        # 기존 상태가 확인 완료가 아니면 변경
        if row["work_status"] != "확인 완료":

            work_list.at[index, "work_status"] = "확인 완료"

            work_list.at[index, "work_status_code"] = 2

            auto_completed_locations.append(location)


# 작업 상태 JSON 다시 저장
work_status_data = work_list[
    [
        "location",
        "reason",
        "priority",
        "work_status",
        "work_status_code"
    ]
].to_dict(orient="records")

with open("work_status.json", "w", encoding="utf-8") as file:
    json.dump(
        work_status_data,
        file,
        ensure_ascii=False,
        indent=4
    )


# 갱신된 작업 완료율 다시 계산
total_work = len(work_list)

completed_work = int(
    (work_list["work_status"] == "확인 완료").sum()
)

progress_work = int(
    (work_list["work_status"] == "확인 중").sum()
)

waiting_work = int(
    (work_list["work_status"] == "확인 대기").sum()
)

if total_work == 0:
    completion_rate = 100.0
else:
    completion_rate = completed_work / total_work * 100


# 작업 진행률 파일 갱신
progress_summary = {
    "total": total_work,
    "completed": completed_work,
    "in_progress": progress_work,
    "waiting": waiting_work,
    "completion_rate": round(completion_rate, 1)
}

with open("work_progress.json", "w", encoding="utf-8") as file:
    json.dump(
        progress_summary,
        file,
        ensure_ascii=False,
        indent=4
    )


# 결과 출력
if auto_completed_locations:

    for location in auto_completed_locations:
        print(f"{location} → 현장 확인 완료! 작업 상태 자동 변경")

else:
    print("새롭게 완료 처리할 재확인 작업이 없습니다.")

print(f"\n현재 작업 완료: {completed_work}/{total_work}개")
print(f"현재 작업 완료율: {completion_rate:.1f}%")
print("work_status.json 갱신 완료!")
print("work_progress.json 갱신 완료!")
# ===== STEP 48: 최종 보고서 및 진행률 동기화 =====

print("\n===== 최종 작업 상태 동기화 =====")

# 1. STEP 47에서 갱신된 작업 상태로 목록 다시 분리
completed_list = work_list[
    work_list["work_status"] == "확인 완료"
].copy()

remaining_list = work_list[
    work_list["work_status"] != "확인 완료"
].copy()


# 2. 최신 작업 완료 여부 판단
if total_work == 0:
    final_status = "재확인 대상 없음"

elif completed_work == total_work:
    final_status = "작업 완료"

else:
    final_status = "진행 중"


# 3. 최신 재고 상태 판단
if total_work > 0 and completed_work < total_work:
    updated_inventory_status = "재확인 작업 진행 중"

elif final_anomaly_count == 0:
    updated_inventory_status = "ALL PASS"

else:
    updated_inventory_status = "재고 이상 또는 미해결 항목 존재"


# 4. 최종 보고서의 작업 정보 갱신
final_report["total_recheck"] = total_work
final_report["completed_recheck"] = completed_work
final_report["in_progress_recheck"] = progress_work
final_report["waiting_recheck"] = waiting_work
final_report["completion_rate"] = round(completion_rate, 1)
final_report["final_status"] = final_status
final_report["inventory_status"] = updated_inventory_status


# 5. 완료 및 미완료 랙 목록 갱신
final_report["completed_locations"] = completed_list[
    ["location", "reason", "work_status"]
].to_dict(orient="records")

final_report["remaining_locations"] = remaining_list[
    ["location", "reason", "work_status"]
].to_dict(orient="records")


# 6. 최종 보고서 다시 저장
with open("final_report.json", "w", encoding="utf-8") as file:
    json.dump(
        final_report,
        file,
        ensure_ascii=False,
        indent=4
    )


# 7. 최신 진행률 막대 출력
bar_length = 30

filled_length = round(
    bar_length * completion_rate / 100
)

progress_bar = (
    "█" * filled_length
    + "░" * (bar_length - filled_length)
)

print(f"\n작업 진행률: [{progress_bar}] {completion_rate:.1f}%")

print(f"전체 작업: {total_work}개")
print(f"확인 완료: {completed_work}개")
print(f"확인 중: {progress_work}개")
print(f"확인 대기: {waiting_work}개")

print(f"\n최종 작업 상태: {final_status}")
print(f"최종 재고 상태: {updated_inventory_status}")

print("\nfinal_report.json 최신 상태 반영 완료!")
# ===== STEP 49: 최종 재고실사 CSV 출력 =====

print("\n===== 최종 재고실사 CSV 생성 =====")

# 최종 통합 재고 데이터 복사
export_inventory = final_inventory.copy()

# CSV에 필요한 항목만 선택
export_inventory = export_inventory[
    [
        "location",
        "product_id_expected",
        "product_id_detected",
        "status_code",
        "status",
        "verification_source"
    ]
].copy()

# 엑셀에서 보기 편하도록 컬럼 이름 변경
export_inventory = export_inventory.rename(
    columns={
        "location": "랙 위치",
        "product_id_expected": "전산 제품 ID",
        "product_id_detected": "최종 확인 제품 ID",
        "status_code": "판정 코드",
        "status": "최종 판정",
        "verification_source": "판정 출처"
    }
)

# ===== STEP 50: 이상 및 미해결 랙 CSV 생성 =====

print("\n===== 이상 및 미해결 랙 CSV 생성 =====")

# 최종 재고 판정 결과에서 정상 제외
anomaly_export = final_inventory[
    final_inventory["status_code"] != 1
].copy()

# 필요한 컬럼 선택
anomaly_export = anomaly_export[
    [
        "location",
        "product_id_expected",
        "product_id_detected",
        "status_code",
        "status",
        "verification_source"
    ]
].copy()

# 컬럼 이름 한글로 변경
anomaly_export = anomaly_export.rename(
    columns={
        "location": "랙 위치",
        "product_id_expected": "전산 제품 ID",
        "product_id_detected": "최종 판정 제품 ID",
        "status_code": "판정 코드",
        "status": "최종 판정",
        "verification_source": "판정 출처"
    }
)

# 랙 위치 순서대로 정렬
anomaly_export = anomaly_export.sort_values(
    by="랙 위치"
)

# CSV 파일 저장
anomaly_export.to_csv(
    "final_anomalies_report.csv",
    index=False,
    encoding="utf-8-sig"
)

# 결과 출력
print(f"이상 및 미해결 랙: {len(anomaly_export)}개")

if anomaly_export.empty:
    print("ALL PASS - 이상 및 미해결 랙이 없습니다.")

else:
    print("\n[이상 및 미해결 랙 목록]")

    print(
        anomaly_export[
            ["랙 위치", "최종 판정", "판정 출처"]
        ].to_string(index=False)
    )

print("\nfinal_anomalies_report.csv 저장 완료!")


# ===== F-04 처리 완료 =====
# ===== STEP 51: 이상 원인 및 현장 조치 안내 =====

print("\n===== 이상 원인 및 현장 조치 안내 =====")

# 판정 상태별 원인 설명
reason_rules = {
    "오적재": "전산 제품과 감지 제품이 다름",
    "누락": "전산에는 제품이 있으나 현장에서 감지되지 않음",
    "미등록": "전산에 없는 제품이 감지됨",
    "수동확인": "AI 판독 결과가 불확실함",
    "미촬영": "해당 랙의 촬영 데이터가 없음"
}

# 판정 상태별 현장 조치 안내
action_rules = {
    "오적재": "실제 제품 ID 확인 후 전산 정보와 비교",
    "누락": "해당 랙의 제품 유무 직접 확인",
    "미등록": "제품 ID 확인 후 전산 등록 여부 점검",
    "수동확인": "해당 랙 재촬영 또는 직접 확인",
    "미촬영": "해당 랙 촬영 후 AI 분석 재실행"
}

# STEP 50에서 만든 이상 목록 복사
action_export = anomaly_export.copy()

# 이상 원인 추가
action_export["이상 원인"] = action_export[
    "최종 판정"
].map(reason_rules)

# 현장 조치 안내 추가
action_export["현장 조치 안내"] = action_export[
    "최종 판정"
].map(action_rules)

# 안내 규칙에 없는 상태 처리
action_export["이상 원인"] = action_export[
    "이상 원인"
].fillna("원인 확인 필요")

action_export["현장 조치 안내"] = action_export[
    "현장 조치 안내"
].fillna("관리자 확인 필요")

# CSV 파일 저장
action_export.to_csv(
    "final_action_report.csv",
    index=False,
    encoding="utf-8-sig"
)

# 결과 출력
if action_export.empty:
    print("ALL PASS - 현장 조치 대상이 없습니다.")

else:
    for _, row in action_export.iterrows():
        print(f'\n랙 위치: {row["랙 위치"]}')
        print(f'판정: {row["최종 판정"]}')
        print(f'이상 원인: {row["이상 원인"]}')
        print(f'현장 조치: {row["현장 조치 안내"]}')

print("\nfinal_action_report.csv 저장 완료!")
# ===== STEP 52: 현장 조치 우선순위 자동 분류 =====

print("\n===== 현장 조치 우선순위 =====")

# 판정 상태별 우선순위 규칙
action_priority_rules = {
    "오적재": 1,
    "누락": 1,
    "미등록": 2,
    "수동확인": 3,
    "미촬영": 4
}

# STEP 51에서 만든 현장 조치 목록 복사
priority_export = action_export.copy()

# 우선순위 부여
priority_export["조치 우선순위"] = priority_export[
    "최종 판정"
].map(action_priority_rules)

# 규칙에 없는 상태는 5순위로 처리
priority_export["조치 우선순위"] = priority_export[
    "조치 우선순위"
].fillna(5).astype(int)

# 우선순위와 랙 위치 기준으로 정렬
priority_export = priority_export.sort_values(
    by=["조치 우선순위", "랙 위치"]
)

# 우선순위를 첫 번째 컬럼으로 이동
priority_columns = ["조치 우선순위"] + [
    col for col in priority_export.columns
    if col != "조치 우선순위"
]

priority_export = priority_export[priority_columns]

# CSV 파일 저장
priority_export.to_csv(
    "final_priority_report.csv",
    index=False,
    encoding="utf-8-sig"
)

# 결과 출력
if priority_export.empty:
    print("ALL PASS - 현장 조치 대상이 없습니다.")

else:
    print("\n[우선순위별 현장 조치 목록]")

    for _, row in priority_export.iterrows():
        print(
            f'{row["조치 우선순위"]}순위 | '
            f'{row["랙 위치"]} | '
            f'{row["최종 판정"]}'
        )

        print(f'  조치: {row["현장 조치 안내"]}')

print("\nfinal_priority_report.csv 저장 완료!")
# ===== STEP 53: 현장 확인 완료 / 미완료 목록 분리 =====

print("\n===== 현장 작업자용 확인 목록 =====")

# STEP 52에서 만든 우선순위 목록 복사
worker_export = priority_export.copy()

# 실제 현장 확인 기록이 있는 랙 위치
verified_locations = set(verified_map.keys())

# 현장 확인 여부 표시
worker_export["현장 확인 상태"] = worker_export[
    "랙 위치"
].apply(
    lambda location: (
        "확인 완료"
        if location in verified_locations
        else "확인 필요"
    )
)

# 확인 완료 목록
worker_completed = worker_export[
    worker_export["현장 확인 상태"] == "확인 완료"
].copy()

# 확인 필요 목록
worker_pending = worker_export[
    worker_export["현장 확인 상태"] == "확인 필요"
].copy()

# 확인 완료 CSV 저장
worker_completed.to_csv(
    "worker_completed.csv",
    index=False,
    encoding="utf-8-sig"
)

# 확인 필요 CSV 저장
worker_pending.to_csv(
    "worker_pending.csv",
    index=False,
    encoding="utf-8-sig"
)

# 결과 출력
print(f"현장 확인 완료: {len(worker_completed)}개")
print(f"현장 확인 필요: {len(worker_pending)}개")

print("\n[현장 확인 완료 목록]")

if worker_completed.empty:
    print("없음")
else:
    for _, row in worker_completed.iterrows():
        print(
            f'{row["랙 위치"]} → '
            f'{row["최종 판정"]} | 확인 완료'
        )

print("\n[현장 확인 필요 목록]")

if worker_pending.empty:
    print("없음")
else:
    for _, row in worker_pending.iterrows():
        print(
            f'{row["조치 우선순위"]}순위 | '
            f'{row["랙 위치"]} → '
            f'{row["최종 판정"]}'
        )

print("\nworker_completed.csv 저장 완료!")
print("worker_pending.csv 저장 완료!")
# ===== STEP 54: 현장 작업 지시서 자동 생성 =====

print("\n===== 현장 작업 지시서 생성 =====")

# STEP 53에서 만든 확인 필요 목록 복사
work_order = worker_pending.copy()

# 작업 지시서에 필요한 컬럼만 선택
work_order = work_order[
    [
        "조치 우선순위",
        "랙 위치",
        "전산 제품 ID",
        "최종 판정 제품 ID",
        "최종 판정",
        "이상 원인",
        "현장 조치 안내",
        "현장 확인 상태"
    ]
].copy()

# 작업 순서 번호 추가
work_order.insert(
    0,
    "작업 번호",
    range(1, len(work_order) + 1)
)

# 작업 지시서 CSV 저장
work_order.to_csv(
    "work_order.csv",
    index=False,
    encoding="utf-8-sig"
)

# 작업 지시서 출력
print(f"총 작업 지시: {len(work_order)}건")

if work_order.empty:
    print("ALL PASS - 추가 현장 확인 작업이 없습니다.")

else:
    for _, row in work_order.iterrows():

        print("\n------------------------------")
        print(f'작업 번호: {row["작업 번호"]}')
        print(f'우선순위: {row["조치 우선순위"]}순위')
        print(f'랙 위치: {row["랙 위치"]}')
        print(f'최종 판정: {row["최종 판정"]}')
        print(f'이상 원인: {row["이상 원인"]}')
        print(f'조치 방법: {row["현장 조치 안내"]}')
        print(f'작업 상태: {row["현장 확인 상태"]}')

print("\nwork_order.csv 저장 완료!")
# ===== STEP 55: 현장 작업 지시서 요약 보고서 =====

print("\n===== 현장 작업 지시서 요약 =====")

# STEP 54에서 만든 작업 지시서 사용
total_orders = len(work_order)

# 판정 상태별 작업 건수 계산
order_status_counts = work_order[
    "최종 판정"
].value_counts()

# 우선순위별 작업 건수 계산
order_priority_counts = work_order[
    "조치 우선순위"
].value_counts().sort_index()

# JSON에 저장할 요약 정보
work_order_summary = {
    "project": "InvenAI",
    "module": "F-04",
    "total_work_orders": total_orders,
    "status_counts": {
        str(status): int(count)
        for status, count in order_status_counts.items()
    },
    "priority_counts": {
        str(priority): int(count)
        for priority, count in order_priority_counts.items()
    }
}

# JSON 파일 저장
with open(
    "work_order_summary.json",
    "w",
    encoding="utf-8"
) as file:
    json.dump(
        work_order_summary,
        file,
        ensure_ascii=False,
        indent=4
    )

# 전체 작업 건수 출력
print(f"전체 작업 지시: {total_orders}건")

# 판정 상태별 건수 출력
print("\n[판정 상태별 작업 건수]")

if order_status_counts.empty:
    print("작업 대상 없음")
else:
    for status, count in order_status_counts.items():
        print(f"{status}: {count}건")

# 우선순위별 건수 출력
print("\n[우선순위별 작업 건수]")

if order_priority_counts.empty:
    print("작업 대상 없음")
else:
    for priority, count in order_priority_counts.items():
        print(f"{priority}순위: {count}건")

print("\nwork_order_summary.json 저장 완료!")
# ===== STEP 56: 이상 유형별 터미널 막대그래프 =====

print("\n===== 현장 작업 지시서 유형별 그래프 =====")

# 표시할 이상 유형
chart_statuses = [
    "오적재",
    "누락",
    "미등록",
    "수동확인",
    "미촬영"
]

# 가장 많은 작업 건수 계산
max_count = max(
    order_status_counts.max()
    if not order_status_counts.empty else 0,
    1
)

# 그래프 최대 길이
bar_length = 20

# 유형별 막대그래프 출력
for status in chart_statuses:

    # 해당 유형의 작업 건수
    count = int(order_status_counts.get(status, 0))

    # 건수에 비례한 막대 길이
    filled_length = round(
        count / max_count * bar_length
    )

    # 막대 생성
    bar = "█" * filled_length

    # 그래프 출력
    print(f"{status:<6} | {bar} {count}건")


# 전체 작업 건수 출력
print("\n------------------------------")
print(f"전체 작업 지시: {total_orders}건")

if total_orders == 0:
    print("ALL PASS - 추가 현장 확인 작업이 없습니다.")

else:
    print("현장 확인이 필요한 작업이 남아 있습니다.")

print("\n유형별 작업 그래프 출력 완료!")
# ===== STEP 57: 최종 재고실사 대시보드 =====

print("\n===== InvenAI F-04 최종 대시보드 =====")

# 1. 전체 재고 판정 건수
dashboard_total = len(final_inventory)

# 2. 정상 건수
dashboard_normal = int(
    (final_inventory["status_code"] == 1).sum()
)

# 3. 이상 및 미해결 건수
dashboard_anomaly = int(
    (final_inventory["status_code"] != 1).sum()
)

# 4. 아직 현장 확인이 필요한 작업 지시 건수
dashboard_pending = len(worker_pending)

# 5. 현장 확인 대상 작업의 진행률
# STEP 47~48에서 갱신한 작업 현황 사용
dashboard_work_total = int(total_work)
dashboard_work_completed = int(completed_work)

if dashboard_work_total > 0:
    dashboard_progress = round(
        dashboard_work_completed / dashboard_work_total * 100,
        1
    )
else:
    dashboard_progress = 100.0

# 6. 진행률 막대그래프 생성
progress_bar_length = 20

progress_filled = round(
    dashboard_progress / 100 * progress_bar_length
)

progress_bar = (
    "█" * progress_filled
    + "░" * (progress_bar_length - progress_filled)
)

# 7. 대시보드 출력
print("\n========================================")
print("          InvenAI 재고실사 현황")
print("========================================")

print(f"전체 랙 수        : {dashboard_total}개")
print(f"정상 랙 수        : {dashboard_normal}개")
print(f"이상·미해결 랙 수 : {dashboard_anomaly}개")
print(f"현장 확인 필요    : {dashboard_pending}건")

print("----------------------------------------")

print("현장 확인 작업 진행률")
print(
    f"[{progress_bar}] "
    f"{dashboard_progress}%"
)

print(
    f"완료 {dashboard_work_completed}건 / "
    f"대상 {dashboard_work_total}건"
)

print("----------------------------------------")

# 8. 전체 재고 판정 결과에 따른 안내
if dashboard_anomaly == 0:
    print("최종 판정: ALL PASS")

else:
    print("최종 판정: 이상 또는 미해결 항목 존재")

# 9. 추가 확인 작업에 따른 안내
if dashboard_pending == 0:
    print("추가 현장 확인 작업: 없음")

else:
    print(
        f"추가 현장 확인 작업: "
        f"{dashboard_pending}건"
    )

print("========================================")

# 10. 대시보드 정보 JSON 저장
dashboard_data = {
    "project": "InvenAI",
    "module": "F-04",
    "total_racks": dashboard_total,
    "normal_racks": dashboard_normal,
    "anomaly_racks": dashboard_anomaly,
    "pending_work_orders": dashboard_pending,
    "work_total": dashboard_work_total,
    "work_completed": dashboard_work_completed,
    "work_completion_rate": dashboard_progress
}

with open(
    "dashboard.json",
    "w",
    encoding="utf-8"
) as file:
    json.dump(
        dashboard_data,
        file,
        ensure_ascii=False,
        indent=4
    )

print("\ndashboard.json 저장 완료!")
# ===== STEP 58: 대시보드 데이터 자동 검증 =====

print("\n===== 대시보드 데이터 자동 검증 =====")

# 검증 결과를 저장할 리스트
validation_results = []

# 1. 전체 랙 수 검증
check_total = (
    dashboard_total
    == dashboard_normal + dashboard_anomaly
)

validation_results.append({
    "item": "전체 랙 수 일치",
    "passed": bool(check_total)
})

# 2. 작업 완료 건수 검증
check_completed = (
    0 <= dashboard_work_completed <= dashboard_work_total
)

validation_results.append({
    "item": "작업 완료 건수 정상",
    "passed": bool(check_completed)
})

# 3. 작업 진행률 범위 검증
check_progress_range = (
    0 <= dashboard_progress <= 100
)

validation_results.append({
    "item": "작업 진행률 범위 정상",
    "passed": bool(check_progress_range)
})

# 4. 현장 확인 필요 건수 검증
check_pending = (
    0 <= dashboard_pending <= dashboard_anomaly
)

validation_results.append({
    "item": "현장 확인 필요 건수 정상",
    "passed": bool(check_pending)
})

# 5. 작업 진행률 계산 검증
if dashboard_work_total > 0:
    expected_progress = round(
        dashboard_work_completed
        / dashboard_work_total * 100,
        1
    )
else:
    expected_progress = 100.0

check_progress_calculation = (
    abs(dashboard_progress - expected_progress) < 0.01
)

validation_results.append({
    "item": "작업 진행률 계산 일치",
    "passed": bool(check_progress_calculation)
})

# 6. 검증 결과 출력
for result in validation_results:

    if result["passed"]:
        print(f'[PASS] {result["item"]}')
    else:
        print(f'[FAIL] {result["item"]}')

# 7. 전체 검증 결과 계산
validation_passed = all(
    result["passed"]
    for result in validation_results
)

validation_status = (
    "PASS" if validation_passed else "FAIL"
)

print("\n------------------------------")
print(f"최종 데이터 검증: {validation_status}")

# 8. 검증 결과 JSON 저장
validation_report = {
    "project": "InvenAI",
    "module": "F-04",
    "validation_status": validation_status,
    "total_checks": len(validation_results),
    "passed_checks": sum(
        result["passed"]
        for result in validation_results
    ),
    "failed_checks": sum(
        not result["passed"]
        for result in validation_results
    ),
    "details": validation_results
}

with open(
    "validation_report.json",
    "w",
    encoding="utf-8"
) as file:
    json.dump(
        validation_report,
        file,
        ensure_ascii=False,
        indent=4
    )

print("\nvalidation_report.json 저장 완료!")

if not validation_passed:
    print("주의: 데이터 불일치 항목을 확인하세요.")
# ===== STEP 59: 검증 오류 보고서 자동 생성 =====

print("\n===== 데이터 검증 오류 보고서 =====")

# STEP 58에서 검증에 실패한 항목만 추출
failed_items = [
    result
    for result in validation_results
    if not result["passed"]
]

# 오류 건수 계산
failed_count = len(failed_items)

# 오류 보고서 생성
error_report = {
    "project": "InvenAI",
    "module": "F-04",
    "validation_status": (
        "PASS" if failed_count == 0 else "FAIL"
    ),
    "error_count": failed_count,
    "errors": failed_items
}

# JSON 파일 저장
with open(
    "validation_error_report.json",
    "w",
    encoding="utf-8"
) as file:
    json.dump(
        error_report,
        file,
        ensure_ascii=False,
        indent=4
    )

# 오류 보고서 출력
if failed_count == 0:

    print("검증 오류가 없습니다.")
    print("모든 데이터 검증 항목이 정상입니다.")

else:

    print(f"검증 오류 발생: {failed_count}건")

    for number, error in enumerate(
        failed_items,
        start=1
    ):
        print(
            f'{number}. {error["item"]}'
        )

    print("데이터 확인 및 수정이 필요합니다.")

print("\nvalidation_error_report.json 저장 완료!")
# ===== STEP 60: 최종 결과물 자동 점검 =====

print("\n===== F-04 최종 결과물 점검 =====")

# 검사할 결과물 목록
required_files = get_required_files()

# ===== STEP 29: 최종 결과 파일 검사 =====

file_check_results = check_result_files(required_files)



# 전체 검사 결과 집계
total_files = len(file_check_results)

passed_files = sum(
    result["status"] == "PASS"
    for result in file_check_results
)

failed_files = total_files - passed_files

# 전체 상태 판정
final_file_status = (
    "PASS" if failed_files == 0 else "FAIL"
)

print("\n------------------------------")
print(f"전체 검사 파일: {total_files}개")
print(f"정상 파일: {passed_files}개")
print(f"문제 파일: {failed_files}개")
print(f"최종 파일 점검: {final_file_status}")

# 점검 보고서 생성
file_check_report = {
    "project": "InvenAI",
    "module": "F-04",
    "check_status": final_file_status,
    "total_files": total_files,
    "passed_files": passed_files,
    "failed_files": failed_files,
    "details": file_check_results
}

# JSON 파일 저장
with open(
    "file_check_report.json",
    "w",
    encoding="utf-8"
) as file:
    json.dump(
        file_check_report,
        file,
        ensure_ascii=False,
        indent=4
    )

print("\nfile_check_report.json 저장 완료!")

if failed_files == 0:
    print("모든 필수 결과물의 기본 점검을 통과했습니다.")
else:
    print("주의: 문제가 있는 결과물을 확인하세요.")
# ===== STEP 61: F-04 최종 실행 상태 자동 판정 =====

print("\n===== F-04 최종 실행 상태 판정 =====")

# 1. 데이터 검증 통과 여부
data_check_ok = validation_passed

# 2. 결과물 파일 점검 통과 여부
file_check_ok = (final_file_status == "PASS")

# 3. 최종 실행 성공 여부
execution_success = (
    data_check_ok
    and file_check_ok
)

# 4. 실행 상태 결정
if execution_success:
    execution_status = "SUCCESS"
else:
    execution_status = "FAIL"

# 5. 재고실사 상태 별도 판정
if dashboard_anomaly == 0:
    inventory_status = "ALL PASS"
else:
    inventory_status = "이상 또는 미해결 항목 존재"

# 6. 현장 작업 상태 별도 판정
if dashboard_pending == 0:
    field_work_status = "추가 현장 확인 없음"
else:
    field_work_status = "추가 현장 확인 필요"

# 7. 결과 출력
print("\n========================================")
print("        InvenAI F-04 실행 결과")
print("========================================")

print(
    f"데이터 검증 : "
    f'{"PASS" if data_check_ok else "FAIL"}'
)

print(
    f"파일 점검   : "
    f'{"PASS" if file_check_ok else "FAIL"}'
)

print("----------------------------------------")

print(f"최종 실행 상태 : {execution_status}")
print(f"재고실사 상태  : {inventory_status}")
print(f"현장 작업 상태 : {field_work_status}")

print("----------------------------------------")

if execution_success:
    print("F-04 기본 처리 및 검증 완료")
else:
    print("F-04 검증 실패 - 오류 확인 필요")

print("========================================")

# 8. 최종 실행 결과 JSON 생성
execution_report = {
    "project": "InvenAI",
    "module": "F-04",
    "execution_status": execution_status,
    "data_validation": (
        "PASS" if data_check_ok else "FAIL"
    ),
    "file_validation": (
        "PASS" if file_check_ok else "FAIL"
    ),
    "inventory_status": inventory_status,
    "field_work_status": field_work_status,
    "total_racks": dashboard_total,
    "normal_racks": dashboard_normal,
    "anomaly_racks": dashboard_anomaly,
    "pending_work_orders": dashboard_pending
}

# 9. JSON 파일 저장
with open(
    "execution_report.json",
    "w",
    encoding="utf-8"
) as file:
    json.dump(
        execution_report,
        file,
        ensure_ascii=False,
        indent=4
    )

print("\nexecution_report.json 저장 완료!")
# ===== STEP 62: 최종 결과물 폴더 자동 정리 =====

print("\n===== F-04 최종 결과물 폴더 정리 =====")

# main.py가 있는 프로젝트 폴더
project_dir = Path(__file__).resolve().parent

# 최종 결과물을 저장할 폴더
output_dir = project_dir / "F04_Final_Results"

# 폴더가 없으면 자동 생성
output_dir.mkdir(
    parents=True,
    exist_ok=True
)

# 정리할 최종 결과물 목록
final_files = get_final_files()

# 복사 성공 및 실패 목록
copied_files = []
missing_files = []
copy_failed_files = []

# 결과물 복사
for filename in final_files:

    source = project_dir / filename
    destination = output_dir / filename

    if not source.is_file():
        missing_files.append(filename)
        print(f"[MISSING] {filename}")
        continue

    try:
        shutil.copy2(source, destination)

        copied_files.append(filename)
        print(f"[OK] {filename}")

    except OSError as error:
        copy_failed_files.append(filename)
        print(f"[FAIL] {filename}: {error}")

# 결과 출력
print("\n------------------------------")
print(f"전체 대상 파일: {len(final_files)}개")
print(f"복사 완료: {len(copied_files)}개")
print(f"누락 파일: {len(missing_files)}개")
print(f"복사 실패: {len(copy_failed_files)}개")

print(f"\n결과물 저장 위치:\n{output_dir}")

if not missing_files and not copy_failed_files:
    print("\n최종 결과물 정리 성공!")
else:
    print("\n일부 결과물을 정리하지 못했습니다.")
    print("위의 MISSING 또는 FAIL 항목을 확인하세요.")
# ===== STEP 63: 최종 결과물 ZIP 자동 압축 =====

print("\n===== F-04 최종 결과물 ZIP 압축 =====")

zip_path = create_final_zip(
    project_dir,
    output_dir,
    final_files
)
def copy_final_files(project_dir, output_dir, final_files):
    import shutil

    # 복사 성공 및 실패 목록
    copied_files = []
    missing_files = []
    copy_failed_files = []

    # 결과물 복사
    for filename in final_files:
        source = project_dir / filename
        destination = output_dir / filename

        if not source.is_file():
            missing_files.append(filename)
            print(f"[MISSING] {filename}")
            continue

        try:
            shutil.copy2(source, destination)

            copied_files.append(filename)
            print(f"[OK] {filename}")

        except OSError as error:
            copy_failed_files.append(filename)
            print(f"[FAIL] {filename}: {error}")

    return copied_files, missing_files, copy_failed_files