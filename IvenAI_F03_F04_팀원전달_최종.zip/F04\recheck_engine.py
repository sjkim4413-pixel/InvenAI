# ===== STEP 56: 현장 재확인 판정 엔진 =====

def judge_recheck(expected_product, actual_product):

    expected = str(expected_product).strip().upper()
    actual = str(actual_product).strip().upper()

    if actual == expected:
        return {
            "status_code": 1,
            "status_name": "정상"
        }

    elif actual in ("", "NONE", "NULL", "NAN"):
        return {
            "status_code": 3,
            "status_name": "누락"
        }

    elif expected in ("", "NONE", "NULL", "NAN"):
        return {
            "status_code": 4,
            "status_name": "미등록"
        }

    else:
        return {
            "status_code": 2,
            "status_name": "오적재"
        }