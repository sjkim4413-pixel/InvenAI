import pandas as pd

def merge_inventory(expected, detected):

    merged = pd.merge(
        expected,
        detected,
        on="location",
        how="outer",
        suffixes=("_expected", "_detected"),
        validate="one_to_one"
    )

    print("\n===== 재고 데이터 병합 결과 =====")
    print(merged.to_string(index=False))

    return merged
