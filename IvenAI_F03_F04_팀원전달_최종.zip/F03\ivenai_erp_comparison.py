
import csv
from pathlib import Path

# AI 분석 결과와 테스트 ERP 파일
AI_FILE = Path("IvenAI_integrated_test.csv")
ERP_FILE = Path("IvenAI_integrated_test_ERP.csv")
OUTPUT_FILE = Path("IvenAI_final_comparison.csv")


def read_csv(path):
    with path.open(
        "r", newline="", encoding="utf-8-sig"
    ) as file:
        return list(csv.DictReader(file))


ai_rows = read_csv(AI_FILE)
erp_rows = read_csv(ERP_FILE)

# 랙번호 + 단수를 기준으로 ERP 조회
erp_map = {
    (row["랙번호"], int(row["단수"])): row
    for row in erp_rows
}

results = []

print("===== IvenAI AI vs ERP 비교 =====")

for ai in ai_rows:
    rack = ai["랙번호"]
    floor = int(ai["단수"])

    erp = erp_map.get((rack, floor))

    if erp is None:
        expected = ""
        status = "ERP위치정보없음_재확인"
    else:
        expected = erp["ERP제품ID"].strip()

        detected_ids = [
            item.strip()
            for item in ai["인식제품ID"].split(",")
            if item.strip()
        ]

        if not expected:
            status = "ERP미등록_확인필요"

        elif not detected_ids:
            status = "AI제품ID미인식_재확인"

        elif expected in detected_ids:
            status = "제품ID일치_추가검증필요"

        else:
            status = "제품ID불일치_오적재의심"

    detected = ai["인식제품ID"]

    result = {
        "랙번호": rack,
        "단수": floor,
        "ERP제품ID": expected,
        "AI인식제품ID": detected,
        "YOLO탐지후보수": ai["YOLO탐지후보수"],
        "검토상태": status
    }

    results.append(result)

    print(
        f"{rack} {floor}단 | "
        f"ERP: {expected or '미등록'} | "
        f"AI: {detected or '미인식'} | "
        f"{status}"
    )


# 비교 결과 CSV 저장
with OUTPUT_FILE.open(
    "w", newline="", encoding="utf-8-sig"
) as file:
    writer = csv.DictWriter(
        file,
        fieldnames=[
            "랙번호",
            "단수",
            "ERP제품ID",
            "AI인식제품ID",
            "YOLO탐지후보수",
            "검토상태"
        ]
    )
    writer.writeheader()
    writer.writerows(results)


print("\n===== 비교 결과 요약 =====")
print("전체 비교 위치:", len(results))

for status in sorted(set(r["검토상태"] for r in results)):
    count = sum(
        r["검토상태"] == status
        for r in results
    )
    print(f"{status}: {count}")

print("저장 파일:", OUTPUT_FILE.resolve())
print("STEP 366 완료")
