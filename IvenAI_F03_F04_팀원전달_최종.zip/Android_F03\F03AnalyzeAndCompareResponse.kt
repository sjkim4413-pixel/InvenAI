package com.example.myapp

import com.google.gson.annotations.SerializedName

data class F03AnalyzeAndCompareResponse(
    val status: String,
    val rack: String,

    @SerializedName("total_positions")
    val totalPositions: Int,

    val results: List<F03ComparedPosition>
)

data class F03ComparedPosition(
    val rack: String,
    val floor: Int,

    @SerializedName("erp_product_ids")
    val erpProductIds: List<String>,

    @SerializedName("ai_product_id")
    val aiProductId: String,

    @SerializedName("yolo_candidates")
    val yoloCandidates: Int,

    @SerializedName("review_status")
    val reviewStatus: String
)