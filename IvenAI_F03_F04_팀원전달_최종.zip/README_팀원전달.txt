﻿IvenAI F-03 / F-04 팀원 전달 자료

[구성]
F03: AI 이미지 분석 FastAPI 서버, ERP 비교 코드, YOLO 모델
F04: ERP 비교 및 재고 판정 관련 Python 모듈
Android_F03: Android Retrofit API 연동 Kotlin 파일

[F-03 서버 실행]
1. Python 환경을 준비하고 필요한 라이브러리를 설치합니다.
2. F03 폴더에서 다음 명령어로 실행합니다.

python -m uvicorn f03_api:app --host 0.0.0.0 --port 8082

3. 브라우저에서 http://127.0.0.1:8082/docs 확인

[Android 연결]
Android 에뮬레이터에서 PC 서버 접속 주소:
http://10.0.2.2:8082/

실제 스마트폰에서는 PC의 네트워크 IP로 변경해야 합니다.

[주의사항]
- F03/F04 Python 모듈은 팀원 환경에서 의존성 설치 및 통합 검증이 필요합니다.
- F04는 전체 판정 유형의 정확성 검증이 완료된 상태는 아닙니다.
- Android_F03 파일은 API 연동용이며 독립 실행 앱이 아닙니다.
- AiAuditCamera 및 임시 결과 화면 수정 코드는 포함하지 않았습니다.
- 누님이 만든 OverlayActivity 및 F07 화면 코드는 포함하지 않았습니다.
- 모델 경로 및 ERP 입력 파일 경로를 팀원 환경에서 확인해야 합니다.