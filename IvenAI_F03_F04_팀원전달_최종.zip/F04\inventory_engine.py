# ===== InvenAI 재고 분석 엔진 =====

from pathlib import Path
import pandas as pd

from validator import (
    validate_columns,
    validate_duplicates,
    validate_confidence,
    validate_detection_state,
    validate_location_product,
)


def load_inventory_data():
    """전산 재고와 AI 감지 데이터를 불러옵니다."""

    base_dir = Path(__file__).resolve().parent

    expected_path = base_dir / "expected.csv"
    detected_path = base_dir / "detected.csv"

    expected = pd.read_csv(expected_path)
    detected = pd.read_csv(detected_path)

    return expected, detected


def validate_inventory_data(expected, detected):
    """재고 데이터의 기본 유효성을 검사합니다."""

    validate_columns(expected, detected)
    validate_duplicates(expected, detected)
    validate_confidence(detected)
    validate_detection_state(detected)
    validate_location_product(expected, detected)

    return True

# ===== STEP 43: 재고 비교 및 이상 판정 =====

from merger import merge_inventory
from classifier import check_status


def analyze_inventory(expected, detected):
    """전산 재고와 AI 감지 데이터를 비교하고 상태를 판정합니다."""

    merged = merge_inventory(expected, detected)

    merged["status_code"] = merged.apply(
        check_status,
        axis=1
    )

    return merged