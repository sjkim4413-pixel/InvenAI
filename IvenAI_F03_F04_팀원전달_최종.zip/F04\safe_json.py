import json
import os
import tempfile
from pathlib import Path


def safe_save_json(file_path, data):
    file_path = Path(file_path)
    file_path.parent.mkdir(parents=True, exist_ok=True)

    temp_path = None

    try:
        # 기존 파일과 같은 폴더에 임시 파일 생성
        with tempfile.NamedTemporaryFile(
            mode="w",
            encoding="utf-8",
            suffix=".tmp",
            prefix=file_path.stem + "_",
            dir=file_path.parent,
            delete=False
        ) as temp_file:

            temp_path = Path(temp_file.name)

            json.dump(
                data,
                temp_file,
                ensure_ascii=False,
                indent=4
            )

            temp_file.flush()
            os.fsync(temp_file.fileno())

        # 임시 파일을 최종 파일로 교체
        os.replace(temp_path, file_path)

        return file_path

    finally:
        # 오류 발생 시 남은 임시 파일 정리
        if temp_path is not None and temp_path.exists():
            temp_path.unlink()