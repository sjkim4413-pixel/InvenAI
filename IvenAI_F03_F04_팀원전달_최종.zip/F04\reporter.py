import pandas as pd
import json

def save_inventory_result(merged):
    result = merged[
        [
            "location",
            "product_id_expected",
            "product_id_detected",
            "status_code",
            "status"
        ]
    ].copy()

    result = result.astype(object).where(
        pd.notna(result), None
    )

    result_data = result.to_dict(orient="records")

    save_json("result.json", result_data)

    print("\n전체 재고 결과 JSON 저장 완료!")

    
def save_anomalies_result(anomalies):
    # 이상 재고 데이터를 JSON 저장용으로 변환
    anomaly_data = anomalies.astype(object).where(
        pd.notna(anomalies), None
    )

    anomaly_data = anomaly_data.to_dict(orient="records")

    # 공통 JSON 저장 함수 사용
    save_json("anomalies.json", anomaly_data)

    print("\n이상 재고 결과 JSON 저장 완료!")
    
def count_inventory_status(merged):
    total_count = len(merged)
    status_counts = merged["status"].value_counts().to_dict()

    print("\n===== 재고 상태별 개수 =====")
    print("전체 랙 수:", total_count)

    for status, count in status_counts.items():
        print(f"{status}: {count}개")

    return total_count, status_counts

def count_anomalies(anomalies):
    total_anomalies = len(anomalies)

    anomaly_counts = anomalies["status"].value_counts().to_dict()

    print("\n===== 이상 위치 집계 =====")
    print(f"전체 이상 위치: {total_anomalies}개")

    for status, count in anomaly_counts.items():
        print(f"{status}: {count}개")

    return total_anomalies, anomaly_counts

def save_summary(summary):
    save_json("summary.json", summary)
    print("\n재고 요약 JSON 저장 완료!")
def save_json(filename, data):
    with open(filename, "w", encoding="utf-8") as file:
        json.dump(
            data,
            file,
            ensure_ascii=False,
            indent=4
        )

    print(f"{filename} 저장 완료!")
    
def create_final_zip(project_dir, output_dir, final_files):
    import zipfile

    zip_path = project_dir / "F04_Final_Results.zip"

    # 압축 성공 파일 목록
    zipped_files = []

    # ZIP 압축파일 생성
    with zipfile.ZipFile(
        zip_path,
        "w",
        compression=zipfile.ZIP_DEFLATED
    ) as zip_file:

        for filename in final_files:
            file_path = output_dir / filename

            # 파일이 존재할 때만 압축
            if file_path.is_file():
                zip_file.write(
                    file_path,
                    arcname=filename
                )

                zipped_files.append(filename)
                print(f"[ZIP OK] {filename}")

            else:
                print(f"[ZIP MISSING] {filename}")

    # 압축파일 내부 검사
    with zipfile.ZipFile(zip_path, "r") as zip_file:
        bad_file = zip_file.testzip()
        zip_file_count = len(zip_file.namelist())

    # 최종 결과 출력
    print("\n------------------------------")
    print(f"압축 대상: {len(final_files)}개")
    print(f"압축 완료: {len(zipped_files)}개")
    print(f"ZIP 내부 파일: {zip_file_count}개")

    if (
        len(zipped_files) == len(final_files)
        and bad_file is None
    ):
        print("ZIP 압축 검증: PASS")
        print("최종 결과물 ZIP 생성 성공!")

    else:
        print("ZIP 압축 검증: FAIL")
        print("누락 또는 손상된 파일을 확인하세요.")

    print(f"\nZIP 저장 위치:\n{zip_path}")
    print("\n===== F-04 처리 완료 =====")

    return zip_path
def copy_final_files(project_dir, output_dir, final_files):
    import shutil

    copied_files = []
    missing_files = []
    copy_failed_files = []

    for filename in final_files:
        source = project_dir / filename
        destination = output_dir / filename

        if not source.is_file():
            missing_files.append(filename)
            print(f"[MISSING] {filename}")
            continue

        try:
            shutil.copy2(source, destination)
            copied_files.append(filename)
            print(f"[OK] {filename}")

        except OSError as error:
            copy_failed_files.append(filename)
            print(f"[FAIL] {filename}: {error}")

    return copied_files, missing_files, copy_failed_files

def get_final_files():
    return [
        "final_inventory_report.csv",
        "final_anomalies_report.csv",
        "final_action_report.csv",
        "final_priority_report.csv",
        "worker_completed.csv",
        "worker_pending.csv",
        "work_order.csv",
        "work_order_summary.json",
        "dashboard.json",
        "validation_report.json",
        "validation_error_report.json",
        "file_check_report.json",
        "execution_report.json"
    ]
    
def save_file_check_report(file_check_report):
    save_json("file_check_report.json", file_check_report)

    print("\n파일 검사 보고서 저장 완료!")