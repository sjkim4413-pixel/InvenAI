from fastapi import FastAPI
import pandas as pd
from result_storage import save_analysis_result
from safe_json import safe_save_json
from json_validator import load_json_safely
import csv
import io
from fastapi.responses import StreamingResponse
app = FastAPI(
    title="InvenAI API",
    description="AI 기반 재고 실사 시스템",
    version="1.0.0"
)


@app.get("/")
def home():
    return {
        "project": "InvenAI",
        "status": "running",
        "message": "InvenAI 서버 정상 작동!"
    }


@app.get("/health")
def health_check():
    return {
        "status": "ok"
    }
    
    # ===== STEP 35: 재고 분석 결과 조회 API =====

from pathlib import Path
import json
from fastapi import HTTPException

BASE_DIR = Path(__file__).resolve().parent


@app.get("/inventory/results")
def get_inventory_results():

    file_path = BASE_DIR / "result.json"

    if not file_path.is_file():
        raise HTTPException(
            status_code=404,
            detail="재고 분석 결과 파일이 없습니다."
        )

    with open(file_path, "r", encoding="utf-8") as file:
        results = json.load(file)

    return {
        "project": "InvenAI",
        "total": len(results),
        "results": results
    }
    
    # ===== STEP 36: 이상 재고 조회 API =====

@app.get("/inventory/anomalies")
def get_inventory_anomalies():

    file_path = BASE_DIR / "anomalies.json"

    if not file_path.is_file():
        raise HTTPException(
            status_code=404,
            detail="이상 재고 결과 파일이 없습니다."
        )

    with open(file_path, "r", encoding="utf-8") as file:
        anomalies = json.load(file)

    return {
        "project": "InvenAI",
        "total": len(anomalies),
        "anomalies": anomalies
    }
    
    # ===== STEP 37: 재고 실사 요약 API =====

@app.get("/inventory/summary")
def get_inventory_summary():

    file_path = BASE_DIR / "dashboard.json"

    if not file_path.is_file():
        raise HTTPException(
            status_code=404,
            detail="재고 요약 파일이 없습니다."
        )

    with open(file_path, "r", encoding="utf-8") as file:
        dashboard = json.load(file)

    return dashboard

# ===== STEP 38: 작업 현황 조회 API =====

@app.get("/inventory/work-status")
def get_work_status():

    file_path = BASE_DIR / "work_status.json"

    if not file_path.is_file():
        raise HTTPException(
            status_code=404,
            detail="작업 현황 파일이 없습니다."
        )

    with open(file_path, "r", encoding="utf-8") as file:
        work_status = json.load(file)

    return {
        "project": "InvenAI",
        "work_status": work_status
    }
    
    # ===== STEP 39: 통일된 API 응답 형식 =====

def make_response(data, message="요청 성공"):
    return {
        "success": True,
        "message": message,
        "data": data
    }


@app.get("/api/test")
def api_test():
    return make_response(
        data={
            "project": "InvenAI",
            "version": "1.0.0",
            "backend": "FastAPI"
        },
        message="API 응답 테스트 성공!"
    )
    
    # ===== STEP 40: 재고 실사 실행 요청 API =====

from pydantic import BaseModel


class InventoryRequest(BaseModel):
    warehouse_id: str
    zone_id: str


@app.post("/inventory/run")
def run_inventory(request: InventoryRequest):

    return make_response(
        data={
            "warehouse_id": request.warehouse_id,
            "zone_id": request.zone_id,
            "analysis_status": "not_started"
        },
        message="재고 실사 요청을 정상적으로 받았습니다."
    )
    
    # ===== STEP 44: 실제 재고 분석 API =====
from result_storage import save_analysis_result
from inventory_engine import (
    load_inventory_data,
    validate_inventory_data,
    analyze_inventory
)


@app.post("/inventory/analyze")
def inventory_analyze():

    try:
        # 1. CSV 데이터 불러오기
        expected, detected = load_inventory_data()

        # 2. 데이터 유효성 검사
        validate_inventory_data(expected, detected)

        # 3. 실제 재고 비교 및 판정
        result = analyze_inventory(expected, detected)
        
        # 상태 코드와 상태명 분리
        result["status_name"] = result["status_code"].apply(
            lambda x: x[1] if isinstance(x, (tuple, list)) else ""
        )

        result["status_code"] = result["status_code"].apply(
            lambda x: x[0] if isinstance(x, (tuple, list)) else x
        )

        # 4. 결과를 JSON 형태로 변환
        result = result.where(result.notna(), None)
        records = json.loads(result.to_json(
            orient="records",
            force_ascii=False
        ))
        # STEP 50: 최신 분석 결과 자동 저장
        save_analysis_result(records)
        return make_response(
            data={
                "total": len(records),
                "results": records
            },
            message="재고 분석이 완료되었습니다."
        )

    except FileNotFoundError as error:
        raise HTTPException(
            status_code=404,
            detail=f"필요한 CSV 파일이 없습니다: {error}"
        )

    except (ValueError, KeyError, pd.errors.ParserError) as error:
        raise HTTPException(
            status_code=422,
            detail=f"재고 데이터 형식 오류: {error}"
        )

    except Exception as error:
        raise HTTPException(
            status_code=500,
            detail=f"재고 분석 중 서버 오류가 발생했습니다: {error}"
        )
        # ===== STEP 51: 최신 재고 분석 결과 조회 API =====

@app.get("/inventory/latest")
def get_latest_inventory():

    file_path = BASE_DIR / "latest_analysis.json"

    if not file_path.is_file():
        raise HTTPException(
            status_code=404,
            detail="최신 재고 분석 결과가 없습니다."
        )

    with open(file_path, "r", encoding="utf-8") as file:
        records = json.load(file)

    return make_response(
        data={
            "total": len(records),
            "results": records
        },
        message="최신 재고 분석 결과 조회 성공!"
    )
    # ===== STEP 52: 최신 이상 재고 조회 API =====

@app.get("/inventory/latest/anomalies")
def get_latest_anomalies():

    file_path = BASE_DIR / "latest_analysis.json"

    if not file_path.is_file():
        raise HTTPException(
            status_code=404,
            detail="최신 재고 분석 결과가 없습니다."
        )

    with open(file_path, "r", encoding="utf-8") as file:
        records = json.load(file)

    anomalies = [
        row for row in records
        if row.get("status_code") != 1
    ]

    return make_response(
        data={
            "total": len(anomalies),
            "results": anomalies
        },
        message="최신 이상 재고 조회 성공!"
    )
    # ===== STEP 53: 랙 번호별 상세 재고 조회 API =====

@app.get("/inventory/latest/rack/{location}")
def get_latest_rack(location: str):

    file_path = BASE_DIR / "latest_analysis.json"

    if not file_path.is_file():
        raise HTTPException(
            status_code=404,
            detail="최신 재고 분석 결과가 없습니다."
        )

    with open(file_path, "r", encoding="utf-8") as file:
        records = json.load(file)

    # 요청한 랙 번호 찾기
    target_location = location.strip().upper()

    rack = next(
        (
            row for row in records
            if str(row.get("location", "")).upper() == target_location
        ),
        None
    )

    if rack is None:
        raise HTTPException(
            status_code=404,
            detail=f"{target_location} 랙을 찾을 수 없습니다."
        )

    return make_response(
        data=rack,
        message="랙 상세 정보 조회 성공!"
    )
    # ===== STEP 54: 현장 재확인 결과 등록 API =====

from datetime import datetime
from pydantic import Field


class RecheckRequest(BaseModel):
    location: str = Field(min_length=1)
    actual_product_id: str = Field(min_length=1)
    worker_id: str = Field(min_length=1)


@app.post("/inventory/recheck")
def register_recheck(request: RecheckRequest):

    file_path = BASE_DIR / "recheck_records.json"
    inventory_path = BASE_DIR / "latest_analysis.json"

    if not inventory_path.is_file():
        raise HTTPException(
            status_code=404,
            detail="최신 재고 분석 결과가 없습니다."
        )

    with open(inventory_path, "r", encoding="utf-8") as file:
        inventory = json.load(file)

    location = request.location.strip().upper()

    rack_exists = any(
        str(row.get("location", "")).strip().upper() == location
        for row in inventory
    )

    if not rack_exists:
        raise HTTPException(
            status_code=404,
            detail=f"{location} 랙을 찾을 수 없습니다."
        )

    records = load_json_safely(file_path)

    new_record = {
        "location": location,
        "actual_product_id": request.actual_product_id.strip(),
        "worker_id": request.worker_id.strip(),
        "recheck_status": "pending_review",
        "checked_at": datetime.now().astimezone().isoformat()
    }

    records.append(new_record)



    safe_save_json(file_path, records)

    return make_response(
        data=new_record,
        message="현장 재확인 결과가 등록되었습니다."
    )
    # ===== STEP 55: 현장 재확인 기록 조회 API =====

@app.get("/inventory/rechecks")
def get_recheck_records():

    file_path = BASE_DIR / "recheck_records.json"

    if not file_path.is_file():
        return make_response(
            data={
                "total": 0,
                "records": []
            },
            message="등록된 재확인 기록이 없습니다."
        )

    with open(file_path, "r", encoding="utf-8") as file:
        records = json.load(file)

    return make_response(
        data={
            "total": len(records),
            "records": records
        },
        message="현장 재확인 기록 조회 성공!"
    )
    # ===== STEP 57: 현장 재확인 자동 재판정 API =====

from recheck_engine import judge_recheck


class RecheckJudgeRequest(BaseModel):
    location: str
    actual_product_id: str


@app.post("/inventory/recheck/judge")
def recheck_judge(request: RecheckJudgeRequest):

    file_path = BASE_DIR / "latest_analysis.json"

    if not file_path.is_file():
        raise HTTPException(
            status_code=404,
            detail="최신 재고 분석 결과가 없습니다."
        )

    with open(file_path, "r", encoding="utf-8") as file:
        records = json.load(file)

    location = request.location.strip().upper()

    rack = next(
        (
            row for row in records
            if str(row.get("location", "")).strip().upper() == location
        ),
        None
    )

    if rack is None:
        raise HTTPException(
            status_code=404,
            detail=f"{location} 랙을 찾을 수 없습니다."
        )

    expected_product = rack.get("product_id_expected")

    if expected_product is None:
        raise HTTPException(
            status_code=422,
            detail="전산 제품 ID 정보가 없습니다."
        )

    judgment = judge_recheck(
        expected_product,
        request.actual_product_id
    )

    return make_response(
        data={
            "location": location,
            "expected_product_id": expected_product,
            "actual_product_id": request.actual_product_id,
            "status_code": judgment["status_code"],
            "status_name": judgment["status_name"]
        },
        message="현장 재확인 자동 재판정 완료!"
    )
    # ===== STEP 58: 재판정 결과 저장 API =====

@app.post("/inventory/recheck/save")
def save_recheck_judgment(request: RecheckJudgeRequest):

    inventory_path = BASE_DIR / "latest_analysis.json"
    save_path = BASE_DIR / "recheck_judgments.json"

    if not inventory_path.is_file():
        raise HTTPException(
            status_code=404,
            detail="최신 재고 분석 결과가 없습니다."
        )

    with open(inventory_path, "r", encoding="utf-8") as file:
        inventory = json.load(file)

    location = request.location.strip().upper()

    rack = next(
        (
            row for row in inventory
            if str(row.get("location", "")).strip().upper() == location
        ),
        None
    )

    if rack is None:
        raise HTTPException(
            status_code=404,
            detail=f"{location} 랙을 찾을 수 없습니다."
        )

    expected_product = rack.get("product_id_expected")

    if expected_product is None:
        raise HTTPException(
            status_code=422,
            detail="전산 제품 ID 정보가 없습니다."
        )

    judgment = judge_recheck(
        expected_product,
        request.actual_product_id
    )

    record = {
        "location": location,
        "expected_product_id": expected_product,
        "actual_product_id": request.actual_product_id.strip(),
        "status_code": judgment["status_code"],
        "status_name": judgment["status_name"],
        "review_status": "pending_review"
    }

    records = []

    if save_path.is_file():
        with open(save_path, "r", encoding="utf-8") as file:
            records = json.load(file)

    records.append(record)

    safe_save_json(save_path, records)

    return make_response(
        data=record,
        message="재판정 결과가 저장되었습니다."
    )
    # ===== STEP 59: 재판정 결과 조회 API =====

@app.get("/inventory/recheck/judgments")
def get_recheck_judgments():

    file_path = BASE_DIR / "recheck_judgments.json"

    if not file_path.is_file():
        return make_response(
            data={
                "total": 0,
                "records": []
            },
            message="저장된 재판정 결과가 없습니다."
        )

    with open(file_path, "r", encoding="utf-8") as file:
        records = json.load(file)

    return make_response(
        data={
            "total": len(records),
            "records": records
        },
        message="재판정 결과 조회 성공!"
    )
    # ===== STEP 60: 재판정 결과 승인 API =====

from pydantic import Field


class RecheckApprovalRequest(BaseModel):
    location: str = Field(min_length=1)
    approved_by: str = Field(min_length=1)


@app.post("/inventory/recheck/approve")
def approve_recheck(request: RecheckApprovalRequest):

    file_path = BASE_DIR / "recheck_judgments.json"

    if not file_path.is_file():
        raise HTTPException(
            status_code=404,
            detail="저장된 재판정 결과가 없습니다."
        )

    with open(file_path, "r", encoding="utf-8") as file:
        records = json.load(file)

    location = request.location.strip().upper()

    # 해당 랙의 가장 최근 검토 대기 기록 찾기
    target = next(
        (
            row for row in reversed(records)
            if row.get("location") == location
            and row.get("review_status") == "pending_review"
        ),
        None
    )

    if target is None:
        raise HTTPException(
            status_code=404,
            detail="승인할 검토 대기 기록이 없습니다."
        )

    # 승인 상태 변경
    target["review_status"] = "approved"
    target["approved_by"] = request.approved_by.strip()
    target["approved_at"] = datetime.now().astimezone().isoformat()

    safe_save_json(file_path, records)

    return make_response(
        data=target,
        message="재판정 결과가 승인되었습니다."
    )
    # ===== STEP 61: 승인된 재판정 결과 조회 API =====

@app.get("/inventory/recheck/approved")
def get_approved_rechecks():

    file_path = BASE_DIR / "recheck_judgments.json"

    if not file_path.is_file():
        return make_response(
            data={
                "total": 0,
                "records": []
            },
            message="승인된 재판정 결과가 없습니다."
        )

    with open(file_path, "r", encoding="utf-8") as file:
        records = json.load(file)

    approved_records = [
        row for row in records
        if row.get("review_status") == "approved"
    ]

    return make_response(
        data={
            "total": len(approved_records),
            "records": approved_records
        },
        message="승인된 재판정 결과 조회 성공!"
    )
    # ===== STEP 62: 검토 대기 재판정 결과 조회 API =====

@app.get("/inventory/recheck/pending")
def get_pending_rechecks():

    file_path = BASE_DIR / "recheck_judgments.json"

    if not file_path.is_file():
        return make_response(
            data={
                "total": 0,
                "records": []
            },
            message="검토 대기 중인 재판정 결과가 없습니다."
        )

    with open(file_path, "r", encoding="utf-8") as file:
        records = json.load(file)

    pending_records = [
        row for row in records
        if row.get("review_status") == "pending_review"
    ]

    return make_response(
        data={
            "total": len(pending_records),
            "records": pending_records
        },
        message="검토 대기 재판정 결과 조회 성공!"
    )
    
# ===== STEP 63: 재판정 결과 반려 API =====

class RecheckRejectRequest(BaseModel):
    location: str = Field(min_length=1)
    rejected_by: str = Field(min_length=1)
    reject_reason: str = Field(min_length=1)


@app.post("/inventory/recheck/reject")
def reject_recheck(request: RecheckRejectRequest):

    file_path = BASE_DIR / "recheck_judgments.json"

    if not file_path.is_file():
        raise HTTPException(
            status_code=404,
            detail="저장된 재판정 기록이 없습니다."
        )

    with open(file_path, "r", encoding="utf-8") as file:
        records = json.load(file)

    location = request.location.strip().upper()

    # 가장 최근의 검토 대기 기록 찾기
    target = next(
        (
            row for row in reversed(records)
            if str(row.get("location", "")).strip().upper() == location
            and row.get("review_status") == "pending_review"
        ),
        None
    )

    if target is None:
        raise HTTPException(
            status_code=404,
            detail="반려할 검토 대기 기록이 없습니다."
        )

    # 반려 처리
    target["review_status"] = "rejected"
    target["rejected_by"] = request.rejected_by.strip()
    target["reject_reason"] = request.reject_reason.strip()
    target["rejected_at"] = datetime.now().astimezone().isoformat()

    # 파일 저장
    safe_save_json(file_path, records)

    return make_response(
        data=target,
        message="재판정 결과가 반려되었습니다."
    )
    # ===== STEP 64: 반려된 재판정 결과 조회 API =====

@app.get("/inventory/recheck/rejected")
def get_rejected_rechecks():

    file_path = BASE_DIR / "recheck_judgments.json"

    if not file_path.is_file():
        return make_response(
            data={
                "total": 0,
                "records": []
            },
            message="반려된 재판정 결과가 없습니다."
        )

    with open(file_path, "r", encoding="utf-8") as file:
        records = json.load(file)

    rejected_records = [
        row for row in records
        if row.get("review_status") == "rejected"
    ]

    return make_response(
        data={
            "total": len(rejected_records),
            "records": rejected_records
        },
        message="반려된 재판정 결과 조회 성공!"
    )
    # ===== STEP 65: 재판정 관리 대시보드 API =====

@app.get("/inventory/recheck/dashboard")
def get_recheck_dashboard():

    file_path = BASE_DIR / "recheck_judgments.json"

    if not file_path.is_file():
        records = []
    else:
        with open(file_path, "r", encoding="utf-8") as file:
            records = json.load(file)

    pending = sum(
        1 for row in records
        if row.get("review_status") == "pending_review"
    )

    approved = sum(
        1 for row in records
        if row.get("review_status") == "approved"
    )

    rejected = sum(
        1 for row in records
        if row.get("review_status") == "rejected"
    )

    return make_response(
        data={
            "total": len(records),
            "pending": pending,
            "approved": approved,
            "rejected": rejected
        },
        message="재판정 관리 대시보드 조회 성공!"
    )
    # ===== STEP 66: 랙별 최신 재판정 상태 조회 API =====

@app.get("/inventory/recheck/latest-status")
def get_latest_recheck_status():

    file_path = BASE_DIR / "recheck_judgments.json"

    if not file_path.is_file():
        return make_response(
            data={
                "total": 0,
                "records": []
            },
            message="재판정 기록이 없습니다."
        )

    with open(file_path, "r", encoding="utf-8") as file:
        records = json.load(file)

    # 랙별 가장 마지막 저장 기록 선택
    latest_by_rack = {}

    for row in records:
        location = str(
            row.get("location", "")
        ).strip().upper()

        if not location:
            continue

        latest_by_rack[location] = row

    latest_records = list(latest_by_rack.values())

    return make_response(
        data={
            "total": len(latest_records),
            "records": latest_records
        },
        message="랙별 최신 재판정 상태 조회 성공!"
    )
    # ===== STEP 67: 랙별 재판정 전체 이력 조회 API =====

@app.get("/inventory/recheck/history/{location}")
def get_recheck_history(location: str):

    file_path = BASE_DIR / "recheck_judgments.json"

    if not file_path.is_file():
        raise HTTPException(
            status_code=404,
            detail="재판정 기록 파일이 없습니다."
        )

    with open(file_path, "r", encoding="utf-8") as file:
        records = json.load(file)

    rack_location = location.strip().upper()

    history = [
        row for row in records
        if str(row.get("location", "")).strip().upper()
        == rack_location
    ]

    if not history:
        raise HTTPException(
            status_code=404,
            detail=f"{rack_location} 랙의 재판정 기록이 없습니다."
        )

    return make_response(
        data={
            "location": rack_location,
            "total": len(history),
            "records": history
        },
        message="랙별 재판정 이력 조회 성공!"
    )
    # ===== STEP 68: 랙별 재판정 이력 통계 API =====

@app.get("/inventory/recheck/stats/{location}")
def get_recheck_stats(location: str):

    file_path = BASE_DIR / "recheck_judgments.json"

    if not file_path.is_file():
        raise HTTPException(
            status_code=404,
            detail="재판정 기록 파일이 없습니다."
        )

    with open(file_path, "r", encoding="utf-8") as file:
        records = json.load(file)

    rack_location = location.strip().upper()

    rack_records = [
        row for row in records
        if str(row.get("location", "")).strip().upper()
        == rack_location
    ]

    if not rack_records:
        raise HTTPException(
            status_code=404,
            detail=f"{rack_location} 랙의 재판정 기록이 없습니다."
        )

    pending = sum(
        1 for row in rack_records
        if row.get("review_status") == "pending_review"
    )

    approved = sum(
        1 for row in rack_records
        if row.get("review_status") == "approved"
    )

    rejected = sum(
        1 for row in rack_records
        if row.get("review_status") == "rejected"
    )

    return make_response(
        data={
            "location": rack_location,
            "total": len(rack_records),
            "pending": pending,
            "approved": approved,
            "rejected": rejected
        },
        message="랙별 재판정 이력 통계 조회 성공!"
    )
    
    # ===== STEP 94: 최초 AI 분석 vs 승인된 재판정 비교 =====

@app.get("/inventory/final/compare")
def compare_final_inventory():

    analysis_path = BASE_DIR / "latest_analysis.json"
    judgment_path = BASE_DIR / "recheck_judgments.json"

    if not analysis_path.is_file():
        raise HTTPException(
            status_code=404,
            detail="최초 AI 분석 결과가 없습니다."
        )

    with open(analysis_path, "r", encoding="utf-8") as file:
        analysis_records = json.load(file)

    if not isinstance(analysis_records, list):
        raise HTTPException(
            status_code=422,
            detail="최초 AI 분석 데이터 형식이 올바르지 않습니다."
        )

    approved_by_location = {}

    if judgment_path.is_file():
        with open(judgment_path, "r", encoding="utf-8") as file:
            judgments = json.load(file)

        if not isinstance(judgments, list):
            raise HTTPException(
                status_code=422,
                detail="재판정 데이터 형식이 올바르지 않습니다."
            )

        for judgment in judgments:
            if judgment.get("review_status") != "approved":
                continue

            location = str(
                judgment.get("location", "")
            ).strip().upper()

            if location:
                # 같은 랙에 승인 기록이 여러 개라면
                # 파일에 마지막으로 저장된 승인 기록을 사용
                approved_by_location[location] = judgment

    results = []
    changed_count = 0

    for row in analysis_records:

        location = str(
            row.get("location", "")
        ).strip().upper()

        ai_code = row.get("status_code")
        ai_name = row.get("status_name")

        approved = approved_by_location.get(location)

        if approved is not None:
            final_code = approved.get("status_code")
            final_name = approved.get("status_name")
            result_source = "approved_recheck"
        else:
            final_code = ai_code
            final_name = ai_name
            result_source = "ai_analysis"

        changed = str(ai_code) != str(final_code)

        if changed:
            changed_count += 1

        results.append({
            "location": location,
            "ai_status_code": ai_code,
            "ai_status_name": ai_name,
            "final_status_code": final_code,
            "final_status_name": final_name,
            "result_source": result_source,
            "changed": changed
        })

    return make_response(
        data={
            "total": len(results),
            "changed_count": changed_count,
            "results": results
        },
        message="최초 AI 분석과 최종 재판정 비교 성공!"
    )
    # ===== STEP 95: 최종 재고 실사 요약 API =====

@app.get("/inventory/final/summary")
def get_final_inventory_summary():

    comparison = compare_final_inventory()
    data = comparison["data"]
    records = data["results"]

    status_counts = {
        "정상": 0,
        "오적재": 0,
        "누락": 0,
        "미등록": 0,
        "수동확인": 0
    }

    approved_count = 0

    for row in records:

        status_code = row.get("final_status_code")

        status_map = {
            1: "정상",
            2: "오적재",
            3: "누락",
            4: "미등록",
            5: "수동확인"
        }

        try:
            status_name = status_map.get(int(status_code))
        except (TypeError, ValueError):
            status_name = None

        if status_name is None:
            status_name = "기타"

        status_counts[status_name] = (
            status_counts.get(status_name, 0) + 1
        )

        if row.get("result_source") == "approved_recheck":
            approved_count += 1

    total = len(records)
    normal = status_counts["정상"]
    anomalies = total - normal

    return make_response(
        data={
            "total": total,
            "normal": normal,
            "anomalies": anomalies,
            "approved_rechecks": approved_count,
            "changed_count": data["changed_count"],
            "status_counts": status_counts
        },
        message="최종 재고 실사 요약 조회 성공!"
    )
    # ===== STEP 96: 최종 이상 위치 목록 API =====

@app.get("/inventory/final/anomalies")
def get_final_inventory_anomalies():

    comparison = compare_final_inventory()
    records = comparison["data"]["results"]

    anomalies = []

    for row in records:

        status_code = row.get("final_status_code")

        # 정상(1)만 제외
        # 알 수 없는 상태도 확인 대상으로 유지
        try:
            is_normal = int(status_code) == 1
        except (TypeError, ValueError):
            is_normal = False

        if not is_normal:
            anomalies.append({
                "location": row.get("location"),
                "ai_status_code": row.get("ai_status_code"),
                "ai_status_name": row.get("ai_status_name"),
                "final_status_code": row.get("final_status_code"),
                "final_status_name": row.get("final_status_name"),
                "result_source": row.get("result_source"),
                "changed": row.get("changed")
            })

    return make_response(
        data={
            "total": len(anomalies),
            "results": anomalies
        },
        message="최종 이상 위치 조회 성공!"
    )
    # ===== STEP 97: 최종 이상 위치 우선순위 API =====

@app.get("/inventory/final/priority")
def get_final_inventory_priority():

    # 기존 최종 이상 위치 API의 결과 재사용
    response = get_final_inventory_anomalies()

    results = response["data"]["results"]

    # 현장 확인 우선순위
    priority_map = {
        2: 1,  # 오적재
        3: 1,  # 누락
        4: 2,  # 미등록
        5: 3,  # 수동확인
    }

    priority_names = {
        1: "긴급",
        2: "높음",
        3: "일반",
    }

    priority_results = []

    for row in results:

        item = row.copy()

        status_code = int(item["final_status_code"])

        priority = priority_map.get(status_code, 3)

        item["priority"] = priority
        item["priority_name"] = priority_names[priority]

        priority_results.append(item)

    # 우선순위 → 랙 위치 순으로 정렬
    priority_results.sort(
        key=lambda x: (x["priority"], x["location"])
    )

    return make_response(
        data={
            "total": len(priority_results),
            "results": priority_results
        },
        message="최종 이상 위치 우선순위 조회 성공!"
    )
    # ===== STEP 98: 최종 이상 위치 우선순위 요약 API =====

@app.get("/inventory/final/priority/summary")
def get_final_priority_summary():

    response = get_final_inventory_priority()
    results = response["data"]["results"]

    urgent = sum(
        1 for row in results
        if row["priority"] == 1
    )

    high = sum(
        1 for row in results
        if row["priority"] == 2
    )

    normal = sum(
        1 for row in results
        if row["priority"] == 3
    )

    return make_response(
        data={
            "total": len(results),
            "urgent": urgent,
            "high": high,
            "normal": normal
        },
        message="최종 이상 위치 우선순위 요약 성공!"
    )
    # ===== STEP 99: 작업자용 최종 점검 목록 API =====

@app.get("/inventory/final/worklist")
def get_final_worklist():

    response = get_final_inventory_priority()
    results = response["data"]["results"]

    worklist = []

    for row in results:

        priority = row["priority"]

        if priority == 1:
            instruction = "긴급 확인이 필요한 위치입니다."
        elif priority == 2:
            instruction = "우선적으로 현장 재고를 확인하세요."
        else:
            instruction = "일반 점검 대상으로 확인하세요."

        worklist.append({
            "location": row["location"],
            "status_code": row["final_status_code"],
            "status_name": row["final_status_name"],
            "priority": priority,
            "priority_name": row["priority_name"],
            "instruction": instruction
        })

    return make_response(
        data={
            "total": len(worklist),
            "worklist": worklist
        },
        message="작업자용 최종 점검 목록 조회 성공!"
    )
    # ===== STEP 100: 작업자 점검 목록 CSV 다운로드 =====

@app.get("/inventory/final/worklist/download")
def download_final_worklist():

    response = get_final_worklist()
    worklist = response["data"]["worklist"]

    output = io.StringIO()
    output.write("\ufeff")  # 엑셀 한글 깨짐 방지

    writer = csv.writer(output)

    writer.writerow([
        "랙 위치",
        "상태 코드",
        "판정 결과",
        "우선순위",
        "우선순위 이름",
        "작업 안내"
    ])

    for row in worklist:
        writer.writerow([
            row["location"],
            row["status_code"],
            row["status_name"],
            row["priority"],
            row["priority_name"],
            row["instruction"]
        ])

    output.seek(0)

    return StreamingResponse(
        iter([output.getvalue()]),
        media_type="text/csv; charset=utf-8",
        headers={
            "Content-Disposition":
            'attachment; filename="InvenAI_Final_Worklist.csv"'
        }
    )