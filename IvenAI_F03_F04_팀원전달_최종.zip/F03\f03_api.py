﻿
from pathlib import Path
import json

from fastapi import FastAPI, HTTPException

app = FastAPI(
    title="IvenAI F-03 API",
    version="1.0.0"
)

BASE_DIR = Path(__file__).resolve().parent

@app.get("/health")
def health():
    return {
        "module": "F03",
        "status": "ok"
    }

@app.get("/f03/audit/progress")
def get_audit_progress():
    file_path = BASE_DIR / "ivenai_progress_test_updated.json"

    if not file_path.is_file():
        raise HTTPException(
            status_code=404,
            detail="실사 진행 현황 JSON 파일이 없습니다."
        )

    try:
        with open(file_path, "r", encoding="utf-8") as f:
            data = json.load(f)
    except (OSError, json.JSONDecodeError):
        raise HTTPException(
            status_code=500,
            detail="실사 진행 현황 JSON을 읽을 수 없습니다."
        )

    if data.get("data_source") != "SIMULATED_TEST":
        raise HTTPException(
            status_code=422,
            detail="예상하지 못한 데이터 출처입니다."
        )

    return data


@app.get("/f03/audit/ai-results")
def get_ai_results():
    import csv

    file_path = BASE_DIR / "IvenAI_ERP_AI_comparison.csv"

    if not file_path.is_file():
        raise HTTPException(
            status_code=404,
            detail="AI 분석 결과 CSV 파일이 없습니다."
        )

    try:
        with file_path.open(
            "r", encoding="utf-8-sig", newline=""
        ) as f:
            reader = csv.DictReader(f)
            rows = list(reader)

        required = {
            "랙번호", "단수", "ERP_등록수",
            "탐지후보수", "검토상태"
        }

        if not rows or not required.issubset(rows[0]):
            raise ValueError("CSV 데이터 구조가 올바르지 않습니다.")

        results = []

        for row in rows:
            results.append({
                "rack": row["랙번호"],
                "floor": int(row["단수"]),
                "erp_registered": int(row["ERP_등록수"]),
                "ai_candidates": int(row["탐지후보수"]),
                "review_status": row["검토상태"]
            })

    except (OSError, ValueError, KeyError) as e:
        raise HTTPException(
            status_code=500,
            detail=f"AI 분석 결과를 읽지 못했습니다: {e}"
        )

    return {
        "module": "F03",
        "data_source": "AI_TEST_RESULT",
        "total_positions": len(results),
        "results": results
    }

@app.get("/f03/audit/integrated-results")
def get_integrated_results():
    import csv

    file_path = BASE_DIR / "IvenAI_final_comparison.csv"

    if not file_path.is_file():
        raise HTTPException(
            status_code=404,
            detail="통합 AI 비교 결과 CSV 파일이 없습니다."
        )

    try:
        with file_path.open(
            "r",
            encoding="utf-8-sig",
            newline=""
        ) as f:
            reader = csv.DictReader(f)

            required = {
                "랙번호",
                "단수",
                "ERP제품ID",
                "AI인식제품ID",
                "YOLO탐지후보수",
                "검토상태"
            }

            if not reader.fieldnames or not required.issubset(
                set(reader.fieldnames)
            ):
                raise ValueError("CSV 컬럼 구조가 올바르지 않습니다.")

            rows = list(reader)

        results = []

        for row in rows:
            results.append({
                "rack": row["랙번호"],
                "floor": int(row["단수"]),
                "erp_product_id": row["ERP제품ID"],
                "ai_product_id": row["AI인식제품ID"],
                "yolo_candidates": int(row["YOLO탐지후보수"]),
                "review_status": row["검토상태"]
            })

    except (OSError, ValueError, KeyError, TypeError) as e:
        raise HTTPException(
            status_code=500,
            detail=f"통합 AI 결과를 읽지 못했습니다: {e}"
        )

    return {
        "module": "F03",
        "data_source": "INTEGRATED_AI_TEST",
        "total_positions": len(results),
        "results": results
    }

# STEP 386 - Android 촬영 이미지 업로드 API

from fastapi import UploadFile, File, HTTPException
from pathlib import Path
from datetime import datetime
import shutil

UPLOAD_DIR = Path(__file__).resolve().parent / "uploaded_images"
UPLOAD_DIR.mkdir(parents=True, exist_ok=True)


@app.post("/f03/audit/upload-image")
async def upload_audit_image(image: UploadFile = File(...)):

    if image.content_type not in ("image/jpeg", "image/png"):
        raise HTTPException(
            status_code=400,
            detail="JPG 또는 PNG 이미지만 업로드할 수 있습니다."
        )

    extension = (
        ".png" if image.content_type == "image/png" else ".jpg"
    )

    timestamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    filename = f"ivenai_{timestamp}{extension}"
    save_path = UPLOAD_DIR / filename

    try:
        with save_path.open("wb") as buffer:
            shutil.copyfileobj(image.file, buffer)
    finally:
        await image.close()

    return {
        "status": "uploaded",
        "filename": filename,
        "message": "이미지 업로드 성공",
        "analysis_status": "not_started"
    }

# STEP 395 - 업로드된 이미지 AI 분석 API

from fastapi import HTTPException
from fastapi.concurrency import run_in_threadpool
from pathlib import Path

from ivenai_integrated_ai import analyze_image


@app.post("/f03/audit/analyze-image")
async def analyze_uploaded_image(filename: str):

    # 파일명에 경로가 들어오는 것을 방지
    if (
        not filename
        or Path(filename).name != filename
        or "\\" in filename
    ):
        raise HTTPException(
            status_code=400,
            detail="올바르지 않은 파일명입니다."
        )

    image_path = UPLOAD_DIR / filename

    if not image_path.is_file():
        raise HTTPException(
            status_code=404,
            detail="업로드된 이미지를 찾을 수 없습니다."
        )

    try:
        result = await run_in_threadpool(
            analyze_image,
            image_path,
            "A01"
        )

        return result

    except (ValueError, FileNotFoundError) as e:
        raise HTTPException(
            status_code=422,
            detail=str(e)
        )

    except Exception:
        import logging
        logging.exception("AI 이미지 분석 실패")

        raise HTTPException(
            status_code=500,
            detail="AI 분석 중 서버 오류가 발생했습니다."
        )
# STEP 419 - 실제 AI 분석 + ERP 전산 비교 API

from ivenai_erp_matcher import compare_with_erp


@app.post("/f03/audit/analyze-and-compare")
async def analyze_and_compare(filename: str):

    # 기존 이미지 분석 API 재사용
    ai_result = await analyze_uploaded_image(filename)

    # ERP 데이터 비교
    comparison = await run_in_threadpool(
        compare_with_erp,
        ai_result
    )

    return {
        "status": "compared",
        "rack": ai_result["rack"],
        "total_positions": comparison["total_positions"],
        "results": comparison["results"]
    }

# STEP 509 - Latest ERP/AI review results
@app.get("/f03/audit/review-results")
def get_review_results():
    import csv

    file_path = BASE_DIR / "IvenAI_STEP502_25_positions_result.csv"

    if not file_path.is_file():
        raise HTTPException(
            status_code=404,
            detail="Review result CSV not found"
        )

    with file_path.open("r", encoding="utf-8-sig", newline="") as f:
        rows = list(csv.DictReader(f))

    required = {
        "rack", "floor", "detected",
        "verification_passed", "final_status"
    }

    if not rows or not required.issubset(rows[0]):
        raise HTTPException(
            status_code=500,
            detail="Invalid review result CSV"
        )

    results = []

    for row in rows:
        results.append({
            "rack": row["rack"],
            "floor": int(row["floor"]),
            "ai_product_id": row["detected"],
            "verification_passed": (
                row["verification_passed"].strip().lower() == "true"
            ),
            "review_status": row["final_status"]
        })

    return {
        "module": "F03",
        "data_source": "STEP502_ERP_AI",
        "total_positions": len(results),
        "results": results
    }
