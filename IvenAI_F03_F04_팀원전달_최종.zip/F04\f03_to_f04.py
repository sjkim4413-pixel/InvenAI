import csv
import json
from pathlib import Path

from f03_input_validator import validate_f03_data


def convert_f03_to_f04(input_path, output_path):
    with open(input_path, "r", encoding="utf-8-sig") as f:
        data = json.load(f)

    valid, message = validate_f03_data(data)

    if not valid:
        raise ValueError(message)

    fields = [
        "location",
        "product_id",
        "confidence",
        "detection_state",
    ]

    with open(
        output_path,
        "w",
        encoding="utf-8-sig",
        newline=""
    ) as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()

        for row in data:
            writer.writerow({
                "location": row["location"],
                "product_id": row["product_id"] or "",
                "confidence": (
                    row["confidence"]
                    if row["confidence"] is not None
                    else ""
                ),
                "detection_state": row["detection_state"],
            })

    return len(data)


if __name__ == "__main__":
    sample = [
        {
            "location": "A02",
            "product_id": "P011",
            "confidence": 0.95,
            "detection_state": "detected",
        },
        {
            "location": "A03",
            "product_id": None,
            "confidence": None,
            "detection_state": "empty",
        },
    ]

    input_file = Path("f03_sample.json")
    output_file = Path("f03_converted_detected.csv")

    input_file.write_text(
        json.dumps(sample, ensure_ascii=False, indent=2),
        encoding="utf-8"
    )

    count = convert_f03_to_f04(input_file, output_file)

    print("INPUT:", input_file)
    print("OUTPUT:", output_file)
    print("CONVERTED ROWS:", count)
    print("STEP 146 PASS - F03 to F04 conversion complete")
