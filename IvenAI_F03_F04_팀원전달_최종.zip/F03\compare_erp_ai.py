﻿import pandas as pd
from pathlib import Path

# 1. ERP 전산 데이터
erp = pd.read_csv(
    "IvenAI_ERP_25_positions.csv",
    encoding="utf-8-sig"
)

# 2. AI 탐지 결과
ai = pd.read_csv(
    "IvenAI_detection_results.csv",
    encoding="utf-8-sig"
)

# 3. 위치 중복 확인
keys = ["랙번호", "단수"]

for name, df in [("ERP", erp), ("AI", ai)]:
    if df.duplicated(keys).any():
        raise ValueError(f"{name} 위치 중복 발견")

# 4. 랙번호 + 단수 기준 통합
result = pd.merge(
    erp,
    ai,
    on=keys,
    how="outer",
    validate="one_to_one",
    indicator=True
)

# 5. 데이터 누락 확인
if not (result["_merge"] == "both").all():
    raise ValueError("ERP와 AI의 위치 목록이 일치하지 않습니다.")

result = result.drop(columns=["_merge"])

# 6. 검토 상태 분류
def review_status(row):
    if row["탐지후보수"] == 0:
        return "AI미탐지_재확인"

    if row["ERP_등록수"] == 0:
        return "ERP미등록_확인필요"

    return "제품ID미검증_확인필요"

result["검토상태"] = result.apply(
    review_status,
    axis=1
)

# 7. 위치 순서 정렬
result = result.sort_values(
    ["랙번호", "단수"]
).reset_index(drop=True)

# 8. CSV 저장
output = Path("IvenAI_ERP_AI_comparison.csv")

result.to_csv(
    output,
    index=False,
    encoding="utf-8-sig"
)

# 9. 결과 출력
print("===== ERP + AI 통합 결과 =====")
print("전체 위치:", len(result))

print("\n===== 검토 상태별 현황 =====")
print(result["검토상태"].value_counts().to_string())

print("\n===== ERP 등록 위치 상세 =====")
print(
    result[result["ERP_등록수"] > 0][
        ["랙번호", "단수", "ERP_왼쪽제품",
         "ERP_오른쪽제품", "탐지후보수", "검토상태"]
    ].to_string(index=False)
)

assert len(result) == 25

print("\n저장 파일:", output.resolve())
print("STEP 307 PASS")
