# ===== InvenAI F-04 재고 상태 판정 모듈 =====

import pandas as pd


def check_status(row):

    expected_id = row["product_id_expected"]
    detected_id = row["product_id_detected"]
    confidence = row["confidence"]
    detection_state = row["detection_state"]

    # 촬영 데이터가 없는 경우
    if pd.isna(detection_state):
        return 5, "미촬영"

    # AI 판독 실패
    if detection_state == "unreadable":
        return 5, "수동확인"

    # 빈 랙 감지
    if detection_state == "empty":
        if pd.notna(expected_id):
            return 3, "누락"

        return 1, "정상"

    # 알 수 없는 감지 상태
    if detection_state != "detected":
        return 5, "수동확인"

    # AI 신뢰도 부족
    if (
        pd.isna(detected_id)
        or pd.isna(confidence)
        or confidence < 0.7
    ):
        return 5, "수동확인"

    # 전산 미등록 제품
    if pd.isna(expected_id):
        return 4, "미등록"

    # 정상 제품
    if expected_id == detected_id:
        return 1, "정상"

    # 오적재
    return 2, "오적재"